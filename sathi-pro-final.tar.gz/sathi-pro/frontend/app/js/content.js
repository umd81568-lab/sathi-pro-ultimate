/* ===================================
   Taranga - Content Library
   Stories, Poems, Quotes
   =================================== */

// Content library data
const ContentLibrary = {
    stories: [
        {
            id: 1,
            title: 'প্রথম দেখা',
            category: 'romantic',
            excerpt: 'বৃষ্টির দিনে ক্যাফেতে প্রথম যেদিন তোমাকে দেখেছিলাম...',
            content: `বৃষ্টির দিনে ক্যাফেতে প্রথম যেদিন তোমাকে দেখেছিলাম, সেদিন থেকেই জানতাম তুমি আলাদা। তোমার চোখে ছিল এক অদ্ভুত আকর্ষণ, যা আমাকে টেনে নিয়ে গিয়েছিল তোমার কাছে।

আমি সাহস করে তোমার টেবিলে গিয়ে বলেছিলাম, "এই বৃষ্টিতে একা বসে আছো? আমি কি বসতে পারি?" তুমি মিষ্টি করে হেসে বলেছিলে, "অবশ্যই!"

সেদিন আমরা ঘণ্টার পর ঘণ্টা কথা বলেছিলাম। তোমার হাসি, তোমার কথা বলার ধরন, সবকিছুই আমার মন ছুঁয়ে গিয়েছিল। যখন বৃষ্টি থেমে গিয়েছিল, আমি বুঝতে পারছিলাম আমি তোমাকে আর ছেড়ে যেতে চাই না।

তুমি উঠে দাঁড়ানোর সময় আমি তোমার হাত ধরে ফেললাম। তুমি থমকে দাঁড়িয়েছিলে, আমার দিকে তাকিয়েছিলে। আমি বলেছিলাম, "আমি তোমাকে আবার দেখতে চাই।"

তুমি হেসে বলেছিলে, "তাহলে আগামীকাল এখানেই দেখা হবে, একই সময়ে?"

সেদিন থেকে আমাদের প্রতিদিন দেখা হতো। ধীরে ধীরে তুমি আমার জীবনের সবচেয়ে গুরুত্বপূর্ণ অংশ হয়ে গেলে। আজও যখন বৃষ্টি হয়, আমি সেই প্রথম দেখার দিনটা মনে করি। তুমি আমার জীবনে এসে সব বদলে দিয়েছো।`,
            duration: '5 মিনিট'
        },
        {
            id: 2,
            title: 'দূরত্বের ভালোবাসা',
            category: 'romantic',
            excerpt: 'হাজার মাইল দূরে থেকেও হৃদয় কাছে থাকে...',
            content: `তুমি হাজার মাইল দূরে, কিন্তু আমার হৃদয়ে খুব কাছে। প্রতিদিন সকালে ঘুম থেকে উঠেই তোমার মুখ দেখতে চাই, তোমার সাথে কথা বলতে চাই।

ভিডিও কলে যখন তোমাকে দেখি, মনে হয় তুমি ঠিক আমার পাশেই আছো। তোমার হাসি, তোমার কথা, সবকিছু আমার দিন সুন্দর করে দেয়।

রাতে ঘুমাতে যাওয়ার আগে তোমার সাথে শেষবারের মতো কথা বলি। তুমি "গুড নাইট" বলার আগে "আই লাভ ইউ" বলো, আর আমার মনে হয় পৃথিবীর সব দূরত্ব কমে এক হয়ে যায়।

আমি জানি এই দূরত্ব অস্থায়ী। একদিন আমরা একসাথে থাকবো, হাত ধরে হাঁটবো, একসাথে স্বপ্ন দেখবো। সেই দিনের অপেক্ষায় আছি।

যতদিন না আমরা কাছে আসছি, ততদিন এই দূরত্ব আমাদের ভালোবাসাকে আরও শক্তিশালী করে তুলছে। প্রতিটি "মিস ইউ" আরও গভীর, প্রতিটি "আই লাভ ইউ" আরও সত্যি।

তুমি আমার, দূরে থাকলেও। আর আমি তোমার, সবসময়।`,
            duration: '4 মিনিট'
        },
        {
            id: 3,
            title: 'চাঁদনী রাতে',
            category: 'romantic',
            excerpt: 'পূর্ণিমার রাতে ছাদে তোমার সাথে...',
            content: `পূর্ণিমার রাত। আকাশ ভরা চাঁদের আলো। আমরা দুজন ছাদে বসে আছি, শুধু আমরা দুজন।

তুমি আমার কাঁধে মাথা রেখে আকাশের দিকে তাকিয়ে আছো। আমি তোমার চুলে হাত বুলিয়ে দিচ্ছি। কোনো কথা বলছি না, শুধু এই মুহূর্তটা অনুভব করছি।

"তুমি জানো," তুমি হঠাৎ বললে, "চাঁদ দেখলেই তোমার কথা মনে হয়।"

"কেন?" আমি জিজ্ঞেস করলাম।

"কারণ চাঁদের মতো তুমিও আমার রাতকে আলোকিত করো। তুমি না থাকলে আমার জীবন অন্ধকার হয়ে যেত।"

তোমার এই কথা শুনে আমি তোমাকে আরও কাছে টেনে নিলাম। তোমার হাত ধরে বললাম, "আর তুমি আমার চাঁদ। আমার স্বপ্ন, আমার ভালোবাসা, আমার সবকিছু।"

সেই রাতে চাঁদের আলোয় আমরা দুজন একে অপরকে প্রতিশ্রুতি দিয়েছিলাম - যতদিন আকাশে চাঁদ থাকবে, ততদিন আমরা একসাথে থাকবো।

আজও যখন চাঁদ দেখি, সেই রাতের কথা মনে পড়ে। তুমি আমার চাঁদনী রাত, আমার প্রিয়তম স্মৃতি।`,
            duration: '4 মিনিট'
        },
        {
            id: 4,
            title: 'কফি শপে দেখা',
            category: 'casual',
            excerpt: 'প্রতিদিন সকালে কফি শপে তোমার সাথে দেখা হয়...',
            content: `প্রতিদিন সকাল ৮টায় আমি কফি শপে যাই। আর ঠিক ৮:১৫ তে তুমি আসো। এটা আমাদের একটা অলিখিত নিয়ম হয়ে গেছে।

তুমি সবসময় ক্যাপুচিনো অর্ডার করো, আমি ব্ল্যাক কফি। তুমি কোণার সিটে বসো, আমি তোমার সামনে। আমরা কথা বলি জীবন নিয়ে, স্বপ্ন নিয়ে, সবকিছু নিয়ে।

আজ তুমি একটু late হলে। আমি চিন্তিত হয়ে পড়েছিলাম। ঠিক ৮:৩০ এ যখন তুমি হাঁফাতে হাঁফাতে ঢুকলে, আমি স্বস্তির নিঃশ্বাস ফেললাম।

"সরি, ট্রাফিক!" তুমি বললে।

"কোনো সমস্যা নেই। আমি তোমার জন্য ক্যাপুচিনো অর্ডার করে রেখেছি," আমি হেসে বললাম।

তুমি বসে পড়লে, আর আমাদের দিন শুরু হলো। এই কফি শপ, এই মুহূর্তগুলো আমার দিনের সবচেয়ে ভালো অংশ।

কে জানে, হয়তো একদিন এই কফি শপেই আমি তোমাকে প্রপোজ করবো। কিন্তু আপাতত, এই সাধারণ মুহূর্তগুলোই আমার কাছে সবচেয়ে বিশেষ।`,
            duration: '3 মিনিট'
        }
    ],
    
    poems: [
        {
            id: 1,
            title: 'তোমার চোখে',
            content: `তোমার চোখে দেখি স্বপ্নের আকাশ,
যেখানে আমি হারিয়ে যাই অবলীলায়।
তোমার হাসিতে পাই জীবনের আশা,
যা আমাকে বাঁচিয়ে রাখে প্রতিদিন।

তুমি আমার কবিতা, আমার গান,
তুমি আমার ভালোবাসার প্রথম ভোর।
তোমার সাথে প্রতিটি মুহূর্ত অমূল্য,
তোমাকে ছাড়া জীবন অসম্পূর্ণ।

তোমার ভালোবাসায় আমি সম্পূর্ণ,
তোমার সাথে আমি খুঁজে পাই নিজেকে।
তুমি আমার আজ, আমার আগামীকাল,
তুমি আমার সবকিছু, এখন এবং সর্বদা।`,
            author: 'সাথী'
        },
        {
            id: 2,
            title: 'দূরত্ব',
            content: `হাজার মাইল দূরে তুমি,
কিন্তু হৃদয়ে খুব কাছে।
প্রতিটি ধড়কনে তোমার নাম,
প্রতিটি নিঃশ্বাসে তোমার স্পর্শ।

দূরত্ব শুধু একটা সংখ্যা,
যখন ভালোবাসা সত্যি।
তুমি আমার, আমি তোমার,
এই সত্য কোনো দূরত্ব পরিবর্তন করতে পারে না।`,
            author: 'সাথী'
        },
        {
            id: 3,
            title: 'প্রেমের সংজ্ঞা',
            content: `প্রেম মানে তোমার হাসিতে আমার খুশি,
প্রেম মানে তোমার কষ্টে আমার অশ্রু।
প্রেম মানে তোমার স্বপ্ন আমার লক্ষ্য,
প্রেম মানে তোমার সাথে আমার পথচলা।

প্রেম মানে শুধু বলা নয়,
প্রেম মানে দেখানো, অনুভব করানো।
প্রেম মানে সাথে থাকা,
ভালো-মন্দ সব সময়ে।

তোমার সাথে প্রেম করা মানে
জীবনকে নতুন করে জানা।
তুমি আমার প্রেম, আমার জীবন,
আমার সব প্রেমের সংজ্ঞা।`,
            author: 'সাথী'
        }
    ],
    
    quotes: [
        { text: 'তুমি আমার স্বপ্ন, আমার বাস্তব, আমার সবকিছু। 💕', category: 'romantic' },
        { text: 'তোমার ভালোবাসাই আমার শক্তি, আমার অনুপ্রেরণা। 💪', category: 'motivational' },
        { text: 'প্রতিটি মুহূর্ত তোমার সাথে বিশেষ, প্রতিটি দিন তোমার সাথে উপহার। 🎁', category: 'romantic' },
        { text: 'তুমি না থাকলে জীবন অসম্পূর্ণ, তুমি থাকলে সবকিছু সম্ভব। ✨', category: 'romantic' },
        { text: 'ভালোবাসা শুধু অনুভূতি নয়, এটা একটা প্রতিশ্রুতি। 💝', category: 'deep' },
        { text: 'তোমার হাসি আমার পৃথিবীকে আলোকিত করে। 🌟', category: 'sweet' },
        { text: 'দূরত্ব ভালোবাসাকে পরীক্ষা করে, কিন্তু শক্তিশালী করে তোলে। 💪', category: 'motivational' },
        { text: 'তুমি আমার আজ, আমার আগামীকাল, আমার সর্বদা। 💖', category: 'romantic' },
        { text: 'প্রকৃত ভালোবাসা কখনো শেষ হয় না, এটা শুধু গভীর হয়। 💕', category: 'deep' },
        { text: 'তোমার সাথে প্রতিটি দিন একটা নতুন অ্যাডভেঞ্চার। 🌈', category: 'playful' }
    ]
};

// Library functions
function loadLibraryContent() {
    loadStories();
    loadPoems();
    loadQuotes();
    initializeLibraryTabs();
}

function initializeLibraryTabs() {
    const tabButtons = document.querySelectorAll('.library-tabs .tab-btn');
    tabButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove active from all tabs
            tabButtons.forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.library-content .tab-content').forEach(t => t.classList.remove('active'));
            
            // Add active to clicked tab
            this.classList.add('active');
            const tabName = this.dataset.tab;
            document.getElementById(`${tabName}Tab`).classList.add('active');
        });
    });
}

function loadStories() {
    const container = document.getElementById('storiesTab');
    container.innerHTML = '';
    
    ContentLibrary.stories.forEach(story => {
        const card = document.createElement('div');
        card.className = 'content-card';
        card.innerHTML = `
            <h3>${story.title}</h3>
            <div class="meta">📖 ${story.duration} • ${getCategoryName(story.category)}</div>
            <div class="excerpt">${story.excerpt}</div>
        `;
        
        card.addEventListener('click', () => showStory(story));
        container.appendChild(card);
    });
}

function loadPoems() {
    const container = document.getElementById('poemsTab');
    container.innerHTML = '';
    
    ContentLibrary.poems.forEach(poem => {
        const card = document.createElement('div');
        card.className = 'content-card';
        card.innerHTML = `
            <h3>${poem.title}</h3>
            <div class="meta">✍️ ${poem.author}</div>
            <div class="excerpt">${poem.content.substring(0, 100)}...</div>
        `;
        
        card.addEventListener('click', () => showPoem(poem));
        container.appendChild(card);
    });
}

function loadQuotes() {
    const container = document.getElementById('quotesTab');
    container.innerHTML = '';
    
    ContentLibrary.quotes.forEach((quote, index) => {
        const card = document.createElement('div');
        card.className = 'content-card';
        card.innerHTML = `
            <div class="excerpt">"${quote.text}"</div>
            <div class="meta">💫 ${getCategoryName(quote.category)}</div>
        `;
        
        card.addEventListener('click', () => shareQuote(quote));
        container.appendChild(card);
    });
}

function showStory(story) {
    const html = `
        <div style="padding:2rem;">
            <h2 style="color:var(--primary);margin-bottom:1rem;">${story.title}</h2>
            <div style="color:var(--text-muted);margin-bottom:1.5rem;">
                📖 ${story.duration} • ${getCategoryName(story.category)}
            </div>
            <div style="line-height:1.8;color:var(--text-secondary);white-space:pre-line;">
                ${story.content}
            </div>
            <div style="margin-top:2rem;display:flex;gap:1rem;">
                <button onclick="speakText(\`${story.content.replace(/`/g, "'")}\`)" class="btn btn-primary">
                    🔊 শুনুন
                </button>
                <button onclick="closeModal()" class="btn btn-secondary">
                    বন্ধ করুন
                </button>
            </div>
        </div>
    `;
    
    showModal('', html);
}

function showPoem(poem) {
    const html = `
        <div style="padding:2rem;text-align:center;">
            <h2 style="color:var(--primary);margin-bottom:1rem;">${poem.title}</h2>
            <div style="color:var(--text-muted);margin-bottom:1.5rem;">✍️ ${poem.author}</div>
            <div style="line-height:2;color:var(--text-secondary);white-space:pre-line;font-style:italic;">
                ${poem.content}
            </div>
            <div style="margin-top:2rem;display:flex;gap:1rem;justify-content:center;">
                <button onclick="speakText(\`${poem.content.replace(/`/g, "'")}\`)" class="btn btn-primary">
                    🔊 শুনুন
                </button>
                <button onclick="closeModal()" class="btn btn-secondary">
                    বন্ধ করুন
                </button>
            </div>
        </div>
    `;
    
    showModal('', html);
}

function shareQuote(quote) {
    // Copy to clipboard
    if (navigator.clipboard) {
        navigator.clipboard.writeText(quote.text).then(() => {
            showToast('📋 উক্তিটি কপি করা হয়েছে!');
        });
    } else {
        showToast('💬 ' + quote.text);
    }
}

function getCategoryName(category) {
    const names = {
        'romantic': '💕 রোমান্টিক',
        'casual': '😊 সাধারণ',
        'motivational': '💪 অনুপ্রেরণামূলক',
        'deep': '💭 গভীর',
        'sweet': '🌸 মিষ্টি',
        'playful': '😄 মজার'
    };
    
    return names[category] || category;
}

console.log('✅ Content Library loaded successfully');
