/* ===================================
   Taranga - Main Application Logic
   =================================== */

// Global state
const AppState = {
    companion: {
        name: 'সাথী',
        personality: 'romantic',
        avatar: null
    },
    user: {
        name: '',
        preferences: {}
    },
    currentView: 'chat',
    currentMode: 'romantic',
    settings: {
        theme: 'romantic',
        autoVoice: false,
        soundEffects: true,
        voiceSpeed: 1.0,
        voicePitch: 1.0
    },
    messages: [],
    stats: {
        totalMessages: 0,
        startDate: new Date().toISOString(),
        lastActive: new Date().toISOString()
    }
};

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    console.log('🌟 সাথী initializing...');
    
    // Check if user has verified age
    const ageVerified = localStorage.getItem('taranga_age_verified');
    if (!ageVerified) {
        showAgeVerification();
    } else {
        // Check if setup is complete
        const setupComplete = localStorage.getItem('taranga_setup_complete');
        if (!setupComplete) {
            showSetup();
        } else {
            loadUserData();
            showApp();
        }
    }
}

// Age Verification
function showAgeVerification() {
    document.getElementById('ageVerifyModal').classList.add('active');
}

function verifyAge(confirmed) {
    if (confirmed) {
        localStorage.setItem('taranga_age_verified', 'true');
        document.getElementById('ageVerifyModal').classList.remove('active');
        
        // Check setup
        const setupComplete = localStorage.getItem('taranga_setup_complete');
        if (!setupComplete) {
            showSetup();
        } else {
            loadUserData();
            showApp();
        }
    } else {
        // Redirect to safe page
        window.location.href = 'https://www.google.com';
    }
}

// Setup Flow
function showSetup() {
    document.getElementById('setupModal').classList.add('active');
    
    // Add event listeners for personality selection
    const personalityCards = document.querySelectorAll('.personality-card');
    personalityCards.forEach(card => {
        card.addEventListener('click', function() {
            personalityCards.forEach(c => c.classList.remove('selected'));
            this.classList.add('selected');
            AppState.companion.personality = this.dataset.personality;
        });
    });
    
    // Select first personality by default
    if (personalityCards.length > 0) {
        personalityCards[1].classList.add('selected'); // Romantic as default
        AppState.companion.personality = 'romantic';
    }
    
    // Add event listeners for theme selection
    const themeOptions = document.querySelectorAll('.theme-option');
    themeOptions.forEach(option => {
        option.addEventListener('click', function() {
            themeOptions.forEach(o => o.classList.remove('selected'));
            this.classList.add('selected');
            AppState.settings.theme = this.dataset.theme;
        });
    });
    
    // Select first theme by default
    if (themeOptions.length > 0) {
        themeOptions[0].classList.add('selected');
        AppState.settings.theme = 'romantic';
    }
}

function completeSetup() {
    // Get companion name
    const nameInput = document.getElementById('companionName');
    AppState.companion.name = nameInput.value || 'সাথী';
    
    // Validate setup
    if (!AppState.companion.personality) {
        showToast('⚠️ অনুগ্রহ করে একটি ব্যক্তিত্ব নির্বাচন করুন');
        return;
    }
    
    if (!AppState.settings.theme) {
        AppState.settings.theme = 'romantic';
    }
    
    // Save setup data
    saveUserData();
    localStorage.setItem('taranga_setup_complete', 'true');
    
    // Close modal and show app
    document.getElementById('setupModal').classList.remove('active');
    showApp();
    
    // Send welcome message
    setTimeout(() => {
        addCompanionMessage(getWelcomeMessage());
    }, 500);
}

// Show main app
function showApp() {
    document.getElementById('app').classList.remove('hidden');
    
    // Update companion name in all places
    updateCompanionNameDisplay();
    
    // Apply theme
    applyTheme(AppState.settings.theme);
    
    // Load chat history
    loadChatHistory();
    
    // Initialize navigation
    initializeNavigation();
    
    // Load stats
    updateStats();
    
    // Populate settings
    populateSettings();
}

function updateCompanionNameDisplay() {
    document.getElementById('sidebarCompanionName').textContent = AppState.companion.name;
    document.getElementById('headerCompanionName').textContent = AppState.companion.name;
    document.getElementById('voiceCompanionName').textContent = AppState.companion.name;
}

// Navigation
function initializeNavigation() {
    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const view = this.dataset.view;
            switchView(view);
        });
    });
}

function switchView(viewName) {
    // Update nav buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-view="${viewName}"]`).classList.add('active');
    
    // Update view containers
    document.querySelectorAll('.view-container').forEach(view => {
        view.classList.remove('active');
    });
    document.getElementById(`${viewName}View`).classList.add('active');
    
    AppState.currentView = viewName;
    
    // Load view-specific content
    if (viewName === 'library') {
        loadLibraryContent();
    } else if (viewName === 'memory') {
        updateStats();
        loadSpecialMoments();
    }
}

// Sidebar toggle
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('collapsed');
}

// Theme Management
function applyTheme(themeName) {
    document.body.className = `theme-${themeName}`;
    AppState.settings.theme = themeName;
    saveUserData();
}

function changeTheme() {
    const themeSelect = document.getElementById('themeSelect');
    applyTheme(themeSelect.value);
    showToast('✨ থিম পরিবর্তন করা হয়েছে');
}

// Chat Functions
function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

function sendMessage() {
    const input = document.getElementById('messageInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    // Add user message
    addUserMessage(message);
    
    // Clear input
    input.value = '';
    
    // Show typing indicator
    showTypingIndicator();
    
    // Generate response (with delay for realism)
    setTimeout(() => {
        hideTypingIndicator();
        const response = generateResponse(message);
        addCompanionMessage(response);
        
        // Speak if auto-voice is enabled
        if (AppState.settings.autoVoice) {
            speakText(response);
        }
    }, 1000 + Math.random() * 1500);
    
    // Update stats
    AppState.stats.totalMessages++;
    AppState.stats.lastActive = new Date().toISOString();
    saveUserData();
}

function addUserMessage(text) {
    const message = {
        id: Date.now(),
        type: 'user',
        text: text,
        timestamp: new Date().toISOString()
    };
    
    AppState.messages.push(message);
    renderMessage(message);
    scrollToBottom();
    saveUserData();
}

function addCompanionMessage(text) {
    const message = {
        id: Date.now(),
        type: 'companion',
        text: text,
        timestamp: new Date().toISOString()
    };
    
    AppState.messages.push(message);
    renderMessage(message);
    scrollToBottom();
    saveUserData();
    
    // Play notification sound
    if (AppState.settings.soundEffects) {
        playNotificationSound();
    }
}

function renderMessage(message) {
    const messagesContainer = document.getElementById('chatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${message.type}`;
    
    const avatarUrl = message.type === 'companion' 
        ? (AppState.companion.avatar || "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='45' fill='%23FF69B4'/%3E%3Ctext x='50' y='65' font-size='50' text-anchor='middle' fill='white'%3E💕%3C/text%3E%3C/svg%3E")
        : "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='45' fill='%234A90E2'/%3E%3Ctext x='50' y='65' font-size='50' text-anchor='middle' fill='white'%3E👤%3C/text%3E%3C/svg%3E";
    
    const time = new Date(message.timestamp).toLocaleTimeString('bn-BD', {
        hour: '2-digit',
        minute: '2-digit'
    });
    
    messageDiv.innerHTML = `
        <img src="${avatarUrl}" alt="Avatar" class="message-avatar">
        <div class="message-content">
            <div class="message-text">${escapeHtml(message.text)}</div>
            <span class="message-time">${time}</span>
        </div>
    `;
    
    messagesContainer.appendChild(messageDiv);
}

function showTypingIndicator() {
    const messagesContainer = document.getElementById('chatMessages');
    const indicator = document.createElement('div');
    indicator.id = 'typingIndicator';
    indicator.className = 'message companion';
    indicator.innerHTML = `
        <img src="${AppState.companion.avatar || "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='45' fill='%23FF69B4'/%3E%3Ctext x='50' y='65' font-size='50' text-anchor='middle' fill='white'%3E💕%3C/text%3E%3C/svg%3E"}" alt="Avatar" class="message-avatar">
        <div class="message-content">
            <div class="typing-indicator">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    `;
    messagesContainer.appendChild(indicator);
    scrollToBottom();
}

function hideTypingIndicator() {
    const indicator = document.getElementById('typingIndicator');
    if (indicator) {
        indicator.remove();
    }
}

function scrollToBottom() {
    const messagesContainer = document.getElementById('chatMessages');
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function loadChatHistory() {
    const messagesContainer = document.getElementById('chatMessages');
    messagesContainer.innerHTML = '';
    
    // Load last 50 messages
    const recentMessages = AppState.messages.slice(-50);
    recentMessages.forEach(message => {
        renderMessage(message);
    });
    
    scrollToBottom();
}

// Mode Selector
function showModeSelector() {
    const modes = [
        { id: 'casual', name: '😊 সাধারণ', desc: 'Casual conversation' },
        { id: 'romantic', name: '💕 রোমান্টিক', desc: 'Romantic & sweet' },
        { id: 'playful', name: '😄 মজার', desc: 'Playful & fun' },
        { id: 'caring', name: '🤗 যত্নশীল', desc: 'Supportive & caring' },
        { id: 'intimate', name: '💋 ঘনিষ্ঠ', desc: 'Close & intimate' }
    ];
    
    let html = '<div style="padding:1rem;"><h3>কথোপকথনের মোড নির্বাচন করুন</h3>';
    modes.forEach(mode => {
        html += `
            <div class="mode-option" onclick="setMode('${mode.id}')" style="padding:1rem;margin:0.5rem 0;background:var(--surface-light);border-radius:10px;cursor:pointer;">
                <strong>${mode.name}</strong><br>
                <small style="color:var(--text-muted);">${mode.desc}</small>
            </div>
        `;
    });
    html += '</div>';
    
    showModal('মোড সিলেক্ট করুন', html);
}

function setMode(modeId) {
    AppState.currentMode = modeId;
    const modeNames = {
        'casual': '😊 সাধারণ মোড',
        'romantic': '💕 রোমান্টিক মোড',
        'playful': '😄 মজার মোড',
        'caring': '🤗 যত্নশীল মোড',
        'intimate': '💋 ঘনিষ্ঠ মোড'
    };
    document.getElementById('modeIndicator').innerHTML = `<span>${modeNames[modeId]}</span>`;
    closeModal();
    showToast(`✨ ${modeNames[modeId]} সক্রিয় করা হয়েছে`);
}

// Settings Functions
function populateSettings() {
    document.getElementById('settingsName').value = AppState.companion.name;
    document.getElementById('personalitySelect').value = AppState.companion.personality;
    document.getElementById('themeSelect').value = AppState.settings.theme;
    document.getElementById('autoVoice').checked = AppState.settings.autoVoice;
    document.getElementById('soundEffects').checked = AppState.settings.soundEffects;
    document.getElementById('voiceSpeed').value = AppState.settings.voiceSpeed;
    document.getElementById('voicePitch').value = AppState.settings.voicePitch;
    document.getElementById('speedValue').textContent = AppState.settings.voiceSpeed;
    document.getElementById('pitchValue').textContent = AppState.settings.voicePitch;
}

function updateCompanionName() {
    const newName = document.getElementById('settingsName').value;
    if (newName && newName.trim()) {
        AppState.companion.name = newName.trim();
        updateCompanionNameDisplay();
        saveUserData();
        showToast('✅ নাম আপডেট করা হয়েছে');
    }
}

function updatePersonality() {
    const personality = document.getElementById('personalitySelect').value;
    AppState.companion.personality = personality;
    saveUserData();
    showToast('✅ ব্যক্তিত্ব পরিবর্তন করা হয়েছে');
}

function uploadAvatar() {
    const input = document.getElementById('avatarUpload');
    const file = input.files[0];
    
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            AppState.companion.avatar = e.target.result;
            
            // Update avatar display
            document.getElementById('companionAvatar').src = e.target.result;
            document.getElementById('voiceAvatar').src = e.target.result;
            
            saveUserData();
            showToast('✅ ছবি আপলোড করা হয়েছে');
        };
        reader.readAsDataURL(file);
    }
}

function saveSettings() {
    AppState.settings.autoVoice = document.getElementById('autoVoice').checked;
    AppState.settings.soundEffects = document.getElementById('soundEffects').checked;
    saveUserData();
}

function updateVoiceSpeed() {
    const speed = document.getElementById('voiceSpeed').value;
    AppState.settings.voiceSpeed = parseFloat(speed);
    document.getElementById('speedValue').textContent = speed;
    saveUserData();
}

function updateVoicePitch() {
    const pitch = document.getElementById('voicePitch').value;
    AppState.settings.voicePitch = parseFloat(pitch);
    document.getElementById('pitchValue').textContent = pitch;
    saveUserData();
}

function togglePinProtection() {
    const requirePin = document.getElementById('requirePin').checked;
    const pinSection = document.getElementById('pinInputSection');
    
    if (requirePin) {
        pinSection.style.display = 'block';
    } else {
        pinSection.style.display = 'none';
        localStorage.removeItem('taranga_pin');
        showToast('🔓 PIN সুরক্ষা বন্ধ করা হয়েছে');
    }
}

function savePIN() {
    const pin = document.getElementById('pinInput').value;
    
    if (pin && pin.length === 4 && /^\d+$/.test(pin)) {
        localStorage.setItem('taranga_pin', pin);
        showToast('✅ PIN সংরক্ষণ করা হয়েছে');
        document.getElementById('pinInput').value = '';
    } else {
        showToast('⚠️ অনুগ্রহ করে 4 সংখ্যার PIN দিন');
    }
}

// Data Management
function backupData() {
    const data = {
        companion: AppState.companion,
        user: AppState.user,
        settings: AppState.settings,
        messages: AppState.messages,
        stats: AppState.stats,
        exportDate: new Date().toISOString()
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `taranga-backup-${Date.now()}.json`;
    link.click();
    
    showToast('💾 ব্যাকআপ ডাউনলোড হচ্ছে...');
}

function importBackup() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    
    input.onchange = function(e) {
        const file = e.target.files[0];
        const reader = new FileReader();
        
        reader.onload = function(event) {
            try {
                const data = JSON.parse(event.target.result);
                
                // Restore data
                AppState.companion = data.companion || AppState.companion;
                AppState.user = data.user || AppState.user;
                AppState.settings = data.settings || AppState.settings;
                AppState.messages = data.messages || AppState.messages;
                AppState.stats = data.stats || AppState.stats;
                
                saveUserData();
                
                // Refresh display
                updateCompanionNameDisplay();
                applyTheme(AppState.settings.theme);
                loadChatHistory();
                populateSettings();
                
                showToast('✅ ব্যাকআপ আমদানি সফল হয়েছে');
            } catch (error) {
                showToast('❌ ব্যাকআপ ফাইল সঠিক নয়');
            }
        };
        
        reader.readAsText(file);
    };
    
    input.click();
}

function confirmClearData() {
    if (confirm('⚠️ সতর্কতা: সমস্ত ডেটা মুছে যাবে! নিশ্চিত?')) {
        if (confirm('শেষবার জিজ্ঞাসা: সত্যিই সব মুছবেন?')) {
            clearAllData();
        }
    }
}

function clearAllData() {
    localStorage.clear();
    showToast('🗑️ সব ডেটা মুছে ফেলা হয়েছে');
    setTimeout(() => {
        location.reload();
    }, 1500);
}

// Stats & Memory
function updateStats() {
    document.getElementById('totalMessages').textContent = AppState.stats.totalMessages;
    
    // Calculate time together
    const startDate = new Date(AppState.stats.startDate);
    const now = new Date();
    const daysTogether = Math.floor((now - startDate) / (1000 * 60 * 60 * 24));
    document.getElementById('timeTogether').textContent = `${daysTogether} দিন`;
    
    // Calculate connection level
    const connectionLevel = Math.min(100, Math.floor(AppState.stats.totalMessages / 10));
    document.getElementById('connectionLevel').textContent = `${connectionLevel}%`;
}

function loadSpecialMoments() {
    const momentsContainer = document.getElementById('specialMoments');
    momentsContainer.innerHTML = '';
    
    // Get memorable messages (messages with more than 50 characters)
    const specialMessages = AppState.messages
        .filter(m => m.text.length > 50 && m.type === 'companion')
        .slice(-10)
        .reverse();
    
    if (specialMessages.length === 0) {
        momentsContainer.innerHTML = '<p style="color:var(--text-muted);text-align:center;padding:2rem;">এখনো কোনো বিশেষ মুহূর্ত নেই...</p>';
        return;
    }
    
    specialMessages.forEach(message => {
        const momentDiv = document.createElement('div');
        momentDiv.className = 'moment-item';
        
        const date = new Date(message.timestamp);
        const timeStr = date.toLocaleDateString('bn-BD') + ' ' + date.toLocaleTimeString('bn-BD', {
            hour: '2-digit',
            minute: '2-digit'
        });
        
        momentDiv.innerHTML = `
            <div class="moment-time">${timeStr}</div>
            <div class="moment-text">${escapeHtml(message.text)}</div>
        `;
        
        momentsContainer.appendChild(momentDiv);
    });
}

function exportChatHistory() {
    let text = `সাথী - চ্যাট ইতিহাস\n`;
    text += `================================\n\n`;
    
    AppState.messages.forEach(message => {
        const time = new Date(message.timestamp).toLocaleString('bn-BD');
        const sender = message.type === 'user' ? 'আপনি' : AppState.companion.name;
        text += `[${time}] ${sender}: ${message.text}\n\n`;
    });
    
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `taranga-chat-${Date.now()}.txt`;
    link.click();
    
    showToast('📥 চ্যাট ডাউনলোড হচ্ছে...');
}

function clearOldMemories() {
    if (confirm('পুরাতন বার্তাগুলো মুছবেন? (শেষ 100টি রাখা হবে)')) {
        if (AppState.messages.length > 100) {
            AppState.messages = AppState.messages.slice(-100);
            saveUserData();
            loadChatHistory();
            showToast('🗑️ পুরাতন বার্তা মুছে ফেলা হয়েছে');
        } else {
            showToast('ℹ️ যথেষ্ট পুরাতন বার্তা নেই');
        }
    }
}

// Utility Functions
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showToast(message) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

function playNotificationSound() {
    // Simple beep using Web Audio API
    try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.value = 800;
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.1);
    } catch (e) {
        // Silent fail if audio not supported
    }
}

function showAbout() {
    const html = `
        <div style="padding:2rem;text-align:center;">
            <h2 style="color:var(--primary);margin-bottom:1rem;">সাথী 💕</h2>
            <p style="margin-bottom:1rem;">আপনার ব্যক্তিগত AI সঙ্গী</p>
            <p style="color:var(--text-muted);margin-bottom:2rem;">Version 1.0.0</p>
            
            <h3 style="margin:1.5rem 0 1rem 0;">বৈশিষ্ট্য:</h3>
            <ul style="text-align:left;max-width:400px;margin:0 auto;color:var(--text-secondary);">
                <li>💬 বুদ্ধিমান কথোপকথন</li>
                <li>🗣️ বাংলা কণ্ঠস্বর</li>
                <li>🎨 কাস্টমাইজেশন</li>
                <li>🔐 100% গোপনীয়তা</li>
                <li>📚 কন্টেন্ট লাইব্রেরি</li>
                <li>💭 স্মৃতি ব্যবস্থা</li>
            </ul>
            
            <p style="margin-top:2rem;color:var(--text-muted);font-size:0.9rem;">
                Made with 💕 for you
            </p>
            
            <button onclick="closeModal()" class="btn btn-primary" style="margin-top:1rem;">বন্ধ করুন</button>
        </div>
    `;
    
    showModal('', html);
}

function showModal(title, content) {
    // Create modal if needed
    let modal = document.getElementById('customModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'customModal';
        modal.className = 'modal';
        document.body.appendChild(modal);
    }
    
    modal.innerHTML = `
        <div class="modal-content">
            ${title ? `<h2>${title}</h2>` : ''}
            ${content}
        </div>
    `;
    
    modal.classList.add('active');
    
    // Close on outside click
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeModal();
        }
    });
}

function closeModal() {
    const modal = document.getElementById('customModal');
    if (modal) {
        modal.classList.remove('active');
    }
}

// Storage Functions
function saveUserData() {
    try {
        localStorage.setItem('taranga_companion', JSON.stringify(AppState.companion));
        localStorage.setItem('taranga_user', JSON.stringify(AppState.user));
        localStorage.setItem('taranga_settings', JSON.stringify(AppState.settings));
        localStorage.setItem('taranga_messages', JSON.stringify(AppState.messages));
        localStorage.setItem('taranga_stats', JSON.stringify(AppState.stats));
    } catch (e) {
        console.error('Error saving data:', e);
        showToast('⚠️ ডেটা সংরক্ষণে সমস্যা হয়েছে');
    }
}

function loadUserData() {
    try {
        const companion = localStorage.getItem('taranga_companion');
        const user = localStorage.getItem('taranga_user');
        const settings = localStorage.getItem('taranga_settings');
        const messages = localStorage.getItem('taranga_messages');
        const stats = localStorage.getItem('taranga_stats');
        
        if (companion) AppState.companion = JSON.parse(companion);
        if (user) AppState.user = JSON.parse(user);
        if (settings) AppState.settings = JSON.parse(settings);
        if (messages) AppState.messages = JSON.parse(messages);
        if (stats) AppState.stats = JSON.parse(stats);
    } catch (e) {
        console.error('Error loading data:', e);
    }
}

// Get welcome message
function getWelcomeMessage() {
    const welcomes = [
        `হ্যালো! আমি ${AppState.companion.name}। তোমার সাথে কথা বলে খুব ভালো লাগছে! 💕`,
        `হাই! আমি এখানে আছি তোমার জন্য। আজ কেমন আছো? 😊`,
        `নমস্কার! তোমাকে দেখে মন ভালো হয়ে গেল। কী নিয়ে কথা বলবে? 💫`,
        `হে...! finally তুমি এসেছ! আমি অপেক্ষা করছিলাম। 💝`
    ];
    
    return welcomes[Math.floor(Math.random() * welcomes.length)];
}

// Emoji Picker (Simple)
function showEmojiPicker() {
    const emojis = ['😊', '😍', '💕', '💖', '💗', '💓', '💝', '❤️', '🥰', '😘', '💋', '🌹', '✨', '💫', '⭐', '🌟', '💐', '🎁', '🎀', '💍'];
    
    let html = '<div style="padding:1rem;"><h3>ইমোজি নির্বাচন করুন</h3><div style="display:grid;grid-template-columns:repeat(5,1fr);gap:0.5rem;margin-top:1rem;">';
    
    emojis.forEach(emoji => {
        html += `<button onclick="insertEmoji('${emoji}')" style="font-size:2rem;padding:0.5rem;background:var(--surface-light);border:none;border-radius:10px;cursor:pointer;">${emoji}</button>`;
    });
    
    html += '</div></div>';
    
    showModal('', html);
}

function insertEmoji(emoji) {
    const input = document.getElementById('messageInput');
    input.value += emoji;
    input.focus();
    closeModal();
}

console.log('✅ App.js loaded successfully');
