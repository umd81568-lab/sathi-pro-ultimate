/* ===================================
   Taranga - Voice System
   Text-to-Speech and Speech-to-Text
   =================================== */

// Voice system state
const VoiceSystem = {
    synthesis: window.speechSynthesis,
    recognition: null,
    isListening: false,
    isSpeaking: false,
    availableVoices: [],
    selectedVoice: null
};

// Initialize voice system
function initializeVoiceSystem() {
    // Get available voices
    if (VoiceSystem.synthesis) {
        VoiceSystem.synthesis.onvoiceschanged = () => {
            VoiceSystem.availableVoices = VoiceSystem.synthesis.getVoices();
            selectBestBengaliVoice();
        };
        
        // Trigger voices loading
        VoiceSystem.availableVoices = VoiceSystem.synthesis.getVoices();
        selectBestBengaliVoice();
    }
    
    // Initialize speech recognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        VoiceSystem.recognition = new SpeechRecognition();
        VoiceSystem.recognition.continuous = false;
        VoiceSystem.recognition.interimResults = false;
        VoiceSystem.recognition.lang = 'bn-BD'; // Bengali
        
        VoiceSystem.recognition.onresult = handleSpeechResult;
        VoiceSystem.recognition.onerror = handleSpeechError;
        VoiceSystem.recognition.onend = handleSpeechEnd;
    }
}

// Select best Bengali voice or female voice
function selectBestBengaliVoice() {
    const voices = VoiceSystem.availableVoices;
    
    // Try to find Bengali voice
    let voice = voices.find(v => v.lang.startsWith('bn'));
    
    // If no Bengali, try Hindi
    if (!voice) {
        voice = voices.find(v => v.lang.startsWith('hi'));
    }
    
    // If no Hindi, try female English voice
    if (!voice) {
        voice = voices.find(v => v.name.toLowerCase().includes('female') && v.lang.startsWith('en'));
    }
    
    // If still no voice, try any female voice
    if (!voice) {
        voice = voices.find(v => v.name.toLowerCase().includes('female'));
    }
    
    // Last resort: first available voice
    if (!voice && voices.length > 0) {
        voice = voices[0];
    }
    
    VoiceSystem.selectedVoice = voice;
    console.log('Selected voice:', voice?.name);
}

// Text-to-Speech function
function speakText(text) {
    if (!VoiceSystem.synthesis) {
        console.error('Speech synthesis not supported');
        return;
    }
    
    // Cancel any ongoing speech
    VoiceSystem.synthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Set voice
    if (VoiceSystem.selectedVoice) {
        utterance.voice = VoiceSystem.selectedVoice;
    }
    
    // Apply user settings
    utterance.rate = AppState.settings.voiceSpeed || 1.0;
    utterance.pitch = AppState.settings.voicePitch || 1.0;
    utterance.volume = 1.0;
    
    // Event handlers
    utterance.onstart = () => {
        VoiceSystem.isSpeaking = true;
        updateVoiceStatus('বলছি...');
    };
    
    utterance.onend = () => {
        VoiceSystem.isSpeaking = false;
        updateVoiceStatus('কথা বলতে প্রস্তুত');
    };
    
    utterance.onerror = (error) => {
        console.error('Speech error:', error);
        VoiceSystem.isSpeaking = false;
        updateVoiceStatus('ভয়েস সমস্যা হয়েছে');
    };
    
    // Speak
    VoiceSystem.synthesis.speak(utterance);
}

// Start voice chat
function startVoiceChat() {
    // Switch to voice view
    switchView('voice');
    
    // Start listening after a moment
    setTimeout(() => {
        startListening();
    }, 500);
}

// Start listening for speech input
function startListening() {
    if (!VoiceSystem.recognition) {
        showToast('⚠️ ভয়েস রিকগনিশন সাপোর্ট করে না');
        return;
    }
    
    if (VoiceSystem.isListening) {
        stopListening();
        return;
    }
    
    try {
        VoiceSystem.recognition.start();
        VoiceSystem.isListening = true;
        updateVoiceStatus('শুনছি... বলুন');
        
        // Add visual feedback
        document.querySelector('.voice-avatar-large').classList.add('listening');
        
    } catch (error) {
        console.error('Recognition start error:', error);
        showToast('⚠️ ভয়েস শুরু করতে সমস্যা হয়েছে');
    }
}

// Stop listening
function stopListening() {
    if (VoiceSystem.recognition && VoiceSystem.isListening) {
        VoiceSystem.recognition.stop();
        VoiceSystem.isListening = false;
        updateVoiceStatus('থামানো হয়েছে');
        
        // Remove visual feedback
        document.querySelector('.voice-avatar-large').classList.remove('listening');
    }
}

// Handle speech recognition result
function handleSpeechResult(event) {
    const transcript = event.results[0][0].transcript;
    console.log('Heard:', transcript);
    
    // Display transcript
    document.getElementById('voiceTranscript').textContent = `আপনি: "${transcript}"`;
    
    // Process the message
    setTimeout(() => {
        const response = generateResponse(transcript);
        document.getElementById('voiceTranscript').textContent += `\n\n${AppState.companion.name}: "${response}"`;
        
        // Speak the response
        speakText(response);
        
        // Add to chat history
        addUserMessage(transcript);
        addCompanionMessage(response);
        
    }, 500);
}

// Handle speech recognition error
function handleSpeechError(event) {
    console.error('Speech recognition error:', event.error);
    
    const errorMessages = {
        'no-speech': 'কোনো কথা শুনতে পাইনি',
        'audio-capture': 'মাইক্রোফোন সমস্যা',
        'not-allowed': 'মাইক্রোফোন অনুমতি দিন',
        'network': 'নেটওয়ার্ক সমস্যা'
    };
    
    const message = errorMessages[event.error] || 'ভয়েস সমস্যা হয়েছে';
    updateVoiceStatus(message);
    showToast(`⚠️ ${message}`);
}

// Handle speech recognition end
function handleSpeechEnd() {
    VoiceSystem.isListening = false;
    updateVoiceStatus('কথা বলতে প্রস্তুত');
    
    // Remove visual feedback
    const avatarLarge = document.querySelector('.voice-avatar-large');
    if (avatarLarge) {
        avatarLarge.classList.remove('listening');
    }
}

// Update voice status display
function updateVoiceStatus(status) {
    const statusElement = document.getElementById('voiceStatus');
    if (statusElement) {
        statusElement.textContent = status;
    }
}

// Toggle voice input in chat
function toggleVoiceInput() {
    if (!VoiceSystem.recognition) {
        showToast('⚠️ ভয়েস রিকগনিশন সাপোর্ট করে না');
        return;
    }
    
    if (VoiceSystem.isListening) {
        stopListening();
    } else {
        // Start listening
        try {
            VoiceSystem.recognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                document.getElementById('messageInput').value = transcript;
            };
            
            VoiceSystem.recognition.start();
            VoiceSystem.isListening = true;
            showToast('🎤 শুনছি...');
            
        } catch (error) {
            console.error('Voice input error:', error);
            showToast('⚠️ ভয়েস সমস্যা হয়েছে');
        }
    }
}

// Stop all voice activities
function stopAllVoice() {
    if (VoiceSystem.synthesis) {
        VoiceSystem.synthesis.cancel();
    }
    
    stopListening();
}

// Initialize when document is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeVoiceSystem);
} else {
    initializeVoiceSystem();
}

console.log('✅ Voice System loaded successfully');
