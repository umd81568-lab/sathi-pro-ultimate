/**
 * সাথী Pro - Advanced Security System
 * Features:
 * - Admin Panel (Password: admin123)
 * - Master Key Protection
 * - Default Recovery Key
 * - Emergency Wipe (54321)
 * - Multi-layer encryption
 */

class SathiSecurity {
    constructor() {
        // Security Keys (Encrypted in production)
        this.ADMIN_PASSWORD = this.hash('admin123');
        this.DEFAULT_MASTER_KEY = this.hash('SATHI_RECOVERY_2026'); // গোপন recovery key
        this.EMERGENCY_WIPE_CODE = this.hash('54321');
        
        // Master Key Storage
        this.masterKey = localStorage.getItem('sathi_master_key');
        this.failedAttempts = 0;
        this.maxFailedAttempts = 5;
        this.lockoutTime = 30 * 60 * 1000; // 30 minutes
        
        // Initialize
        this.init();
    }

    // =====================================
    // Initialization
    // =====================================

    init() {
        // Check if first time
        if (!localStorage.getItem('sathi_initialized')) {
            this.firstTimeSetup();
        }

        // Check lockout
        this.checkLockout();

        // Setup emergency listener
        this.setupEmergencyWipe();
    }

    firstTimeSetup() {
        console.log('🔐 First time setup...');
        
        // Show setup wizard
        this.showMasterKeySetup();
        
        localStorage.setItem('sathi_initialized', 'true');
        localStorage.setItem('sathi_setup_date', new Date().toISOString());
    }

    // =====================================
    // Master Key Management
    // =====================================

    showMasterKeySetup() {
        const modal = document.createElement('div');
        modal.className = 'security-modal';
        modal.innerHTML = `
            <div class="security-modal-content">
                <div class="security-header">
                    <h2>🔐 সাথী সুরক্ষা সেটআপ</h2>
                    <p>আপনার ব্যক্তিগত মাস্টার কী তৈরি করুন</p>
                </div>

                <div class="security-body">
                    <div class="security-info">
                        <p><strong>⚠️ গুরুত্বপূর্ণ:</strong></p>
                        <ul>
                            <li>এই কী দিয়ে সাথী ও সব সেটিংস অ্যাক্সেস করবেন</li>
                            <li>কী হারালে ডিফল্ট recovery key ব্যবহার করতে পারবেন</li>
                            <li>জরুরি অবস্থায় "54321" = সব মুছে যাবে</li>
                        </ul>
                    </div>

                    <div class="input-group">
                        <label>মাস্টার কী তৈরি করুন (5-20 অক্ষর):</label>
                        <input type="password" id="master-key-input" placeholder="আপনার মাস্টার কী">
                        <button onclick="togglePassword('master-key-input')" class="btn-toggle">👁️</button>
                    </div>

                    <div class="input-group">
                        <label>মাস্টার কী নিশ্চিত করুন:</label>
                        <input type="password" id="master-key-confirm" placeholder="আবার লিখুন">
                    </div>

                    <div class="recovery-key-display" id="recovery-key-display" style="display: none;">
                        <p><strong>📋 আপনার Recovery Key:</strong></p>
                        <div class="key-box">
                            <code id="recovery-key-text">SATHI_RECOVERY_2026</code>
                            <button onclick="copyRecoveryKey()" class="btn-copy">📋 Copy</button>
                        </div>
                        <p class="warning">⚠️ এই key নিরাপদ জায়গায় সংরক্ষণ করুন!</p>
                    </div>
                </div>

                <div class="security-footer">
                    <button onclick="createMasterKey()" class="btn-primary">✅ সেটআপ সম্পন্ন করুন</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        // Add styles
        this.addSecurityStyles();
    }

    async createMasterKey(key1, key2) {
        if (!key1 || !key2) {
            alert('⚠️ দুটি ক্ষেত্রই পূরণ করুন!');
            return false;
        }

        if (key1 !== key2) {
            alert('⚠️ মাস্টার কী মিলছে না!');
            return false;
        }

        if (key1.length < 5) {
            alert('⚠️ মাস্টার কী কমপক্ষে ৫ অক্ষর হতে হবে!');
            return false;
        }

        // Hash and store
        const hashedKey = this.hash(key1);
        localStorage.setItem('sathi_master_key', hashedKey);
        this.masterKey = hashedKey;

        // Show recovery key
        document.getElementById('recovery-key-display').style.display = 'block';

        // Log
        this.logSecurityEvent('master_key_created');

        return true;
    }

    async verifyMasterKey(inputKey) {
        // Check emergency wipe
        if (this.hash(inputKey) === this.EMERGENCY_WIPE_CODE) {
            return this.emergencyWipe();
        }

        // Check lockout
        if (this.isLockedOut()) {
            alert('🚫 অনেক ভুল প্রচেষ্টা! 30 মিনিট অপেক্ষা করুন।');
            return false;
        }

        // Verify master key
        if (this.hash(inputKey) === this.masterKey) {
            this.failedAttempts = 0;
            localStorage.removeItem('sathi_lockout_until');
            this.logSecurityEvent('master_key_verified');
            return true;
        }

        // Verify default recovery key
        if (this.hash(inputKey) === this.DEFAULT_MASTER_KEY) {
            this.failedAttempts = 0;
            this.logSecurityEvent('recovery_key_used');
            alert('✅ Recovery key ব্যবহার করা হয়েছে। নতুন মাস্টার কী সেট করুন।');
            return true;
        }

        // Failed attempt
        this.failedAttempts++;
        localStorage.setItem('sathi_failed_attempts', this.failedAttempts);

        if (this.failedAttempts >= this.maxFailedAttempts) {
            this.lockout();
            alert('🚫 অনেক ভুল প্রচেষ্টা! 30 মিনিট lock।');
        } else {
            alert(`❌ ভুল কী! ${this.maxFailedAttempts - this.failedAttempts} প্রচেষ্টা বাকি।`);
        }

        this.logSecurityEvent('master_key_failed', { attempts: this.failedAttempts });
        return false;
    }

    // =====================================
    // Admin Panel Access
    // =====================================

    async verifyAdminPassword(password) {
        if (this.hash(password) === this.ADMIN_PASSWORD) {
            this.logSecurityEvent('admin_access_granted');
            return true;
        }

        this.logSecurityEvent('admin_access_denied');
        return false;
    }

    showAdminLogin() {
        const modal = document.createElement('div');
        modal.className = 'security-modal';
        modal.innerHTML = `
            <div class="security-modal-content">
                <div class="security-header">
                    <h2>🔐 Admin Panel</h2>
                </div>

                <div class="security-body">
                    <div class="input-group">
                        <label>Admin Password:</label>
                        <input type="password" id="admin-password-input" placeholder="Enter admin password">
                    </div>
                </div>

                <div class="security-footer">
                    <button onclick="verifyAdminAccess()" class="btn-primary">Login</button>
                    <button onclick="closeSecurityModal()" class="btn-secondary">Cancel</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
    }

    showMasterKeyPrompt(callback) {
        const modal = document.createElement('div');
        modal.className = 'security-modal';
        modal.innerHTML = `
            <div class="security-modal-content">
                <div class="security-header">
                    <h2>🔐 সাথী অ্যাক্সেস</h2>
                    <p>মাস্টার কী প্রয়োজন</p>
                </div>

                <div class="security-body">
                    <div class="input-group">
                        <label>মাস্টার কী:</label>
                        <input type="password" id="master-key-verify-input" placeholder="আপনার মাস্টার কী">
                    </div>

                    <div class="help-text">
                        <p>কী ভুলে গেছেন? Recovery key ব্যবহার করুন</p>
                        <p class="warning">জরুরি: "54321" = সব মুছে যাবে ⚠️</p>
                    </div>
                </div>

                <div class="security-footer">
                    <button onclick="verifyMasterAccess('${callback}')" class="btn-primary">Unlock</button>
                    <button onclick="closeSecurityModal()" class="btn-secondary">Cancel</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
    }

    // =====================================
    // Emergency Wipe
    // =====================================

    setupEmergencyWipe() {
        // Listen for emergency code
        window.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && e.ctrlKey && e.shiftKey) {
                this.showEmergencyWipeConfirm();
            }
        });
    }

    showEmergencyWipeConfirm() {
        const confirm = window.confirm(
            '⚠️ EMERGENCY WIPE\n\n' +
            'এটি সব ডেটা মুছে ফেলবে:\n' +
            '- সব কথোপকথন\n' +
            '- সব মেমোরি\n' +
            '- সব সেটিংস\n' +
            '- সব আপলোড\n\n' +
            'নিশ্চিত করতে "54321" লিখুন এবং OK করুন'
        );

        if (confirm) {
            const code = prompt('Emergency Code:');
            if (code === '54321') {
                this.emergencyWipe();
            }
        }
    }

    async emergencyWipe() {
        console.log('🚨 EMERGENCY WIPE INITIATED');

        // Show countdown
        let countdown = 5;
        const countdownInterval = setInterval(() => {
            console.log(`⏰ Wiping in ${countdown}...`);
            countdown--;
            if (countdown < 0) {
                clearInterval(countdownInterval);
            }
        }, 1000);

        await new Promise(resolve => setTimeout(resolve, 5000));

        // Clear all localStorage
        localStorage.clear();

        // Clear all sessionStorage
        sessionStorage.clear();

        // Clear all IndexedDB
        if (window.indexedDB) {
            const databases = await indexedDB.databases();
            databases.forEach(db => {
                indexedDB.deleteDatabase(db.name);
            });
        }

        // Clear all cookies
        document.cookie.split(";").forEach(c => {
            document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
        });

        // Clear cache
        if ('caches' in window) {
            caches.keys().then(names => {
                names.forEach(name => caches.delete(name));
            });
        }

        // Notify server to delete data
        if (window.SathiCloud && window.SathiCloud.token) {
            try {
                await fetch(`${window.SathiCloud.apiUrl}/emergency/wipe`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${window.SathiCloud.token}`
                    }
                });
            } catch (e) {
                // Ignore errors - data must be wiped
            }
        }

        // Log and redirect
        console.log('✅ EMERGENCY WIPE COMPLETE');
        alert('🔥 সব ডেটা মুছে ফেলা হয়েছে।\n\nরিস্টার্ট করুন।');

        // Force reload
        window.location.href = 'about:blank';
        setTimeout(() => {
            window.location.reload(true);
        }, 100);

        return true;
    }

    // =====================================
    // Lockout System
    // =====================================

    lockout() {
        const lockoutUntil = Date.now() + this.lockoutTime;
        localStorage.setItem('sathi_lockout_until', lockoutUntil);
        this.logSecurityEvent('lockout_triggered');
    }

    checkLockout() {
        const lockoutUntil = parseInt(localStorage.getItem('sathi_lockout_until') || '0');
        
        if (lockoutUntil > Date.now()) {
            const remainingTime = Math.ceil((lockoutUntil - Date.now()) / 60000);
            alert(`🚫 অ্যাকাউন্ট লক। ${remainingTime} মিনিট অপেক্ষা করুন।`);
            return true;
        }

        // Clear lockout
        localStorage.removeItem('sathi_lockout_until');
        localStorage.removeItem('sathi_failed_attempts');
        this.failedAttempts = 0;
        return false;
    }

    isLockedOut() {
        const lockoutUntil = parseInt(localStorage.getItem('sathi_lockout_until') || '0');
        return lockoutUntil > Date.now();
    }

    // =====================================
    // Utilities
    // =====================================

    hash(str) {
        // Simple hash function (Production এ SHA-256 ব্যবহার করুন)
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return hash.toString(36);
    }

    encrypt(data, key) {
        // Simple XOR encryption (Production এ AES ব্যবহার করুন)
        return btoa(data.split('').map((c, i) => 
            String.fromCharCode(c.charCodeAt(0) ^ key.charCodeAt(i % key.length))
        ).join(''));
    }

    decrypt(encrypted, key) {
        const data = atob(encrypted);
        return data.split('').map((c, i) => 
            String.fromCharCode(c.charCodeAt(0) ^ key.charCodeAt(i % key.length))
        ).join('');
    }

    logSecurityEvent(event, data = {}) {
        const log = {
            event,
            timestamp: new Date().toISOString(),
            data
        };

        const logs = JSON.parse(localStorage.getItem('sathi_security_logs') || '[]');
        logs.push(log);

        // Keep last 100 logs
        if (logs.length > 100) {
            logs.shift();
        }

        localStorage.setItem('sathi_security_logs', JSON.stringify(logs));
        console.log('🔒 Security Event:', log);
    }

    addSecurityStyles() {
        if (document.getElementById('sathi-security-styles')) return;

        const styles = document.createElement('style');
        styles.id = 'sathi-security-styles';
        styles.textContent = `
            .security-modal {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.8);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 10000;
                animation: fadeIn 0.3s;
            }

            .security-modal-content {
                background: white;
                border-radius: 16px;
                max-width: 500px;
                width: 90%;
                max-height: 90vh;
                overflow-y: auto;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            }

            .security-header {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 24px;
                border-radius: 16px 16px 0 0;
                text-align: center;
            }

            .security-header h2 {
                margin: 0 0 8px 0;
                font-size: 24px;
            }

            .security-header p {
                margin: 0;
                opacity: 0.9;
                font-size: 14px;
            }

            .security-body {
                padding: 24px;
            }

            .security-info {
                background: #f8f9fa;
                padding: 16px;
                border-radius: 8px;
                margin-bottom: 20px;
            }

            .security-info ul {
                margin: 8px 0 0 0;
                padding-left: 20px;
            }

            .security-info li {
                margin: 4px 0;
            }

            .input-group {
                margin-bottom: 16px;
            }

            .input-group label {
                display: block;
                margin-bottom: 8px;
                font-weight: 600;
                color: #333;
            }

            .input-group input {
                width: 100%;
                padding: 12px;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                font-size: 16px;
                transition: border-color 0.3s;
            }

            .input-group input:focus {
                outline: none;
                border-color: #667eea;
            }

            .btn-toggle {
                margin-top: 8px;
                padding: 8px 16px;
                background: #f0f0f0;
                border: none;
                border-radius: 6px;
                cursor: pointer;
            }

            .recovery-key-display {
                background: #fff3cd;
                padding: 16px;
                border-radius: 8px;
                margin-top: 20px;
                border: 2px solid #ffc107;
            }

            .key-box {
                background: white;
                padding: 12px;
                border-radius: 6px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin: 12px 0;
            }

            .key-box code {
                font-size: 14px;
                font-weight: 600;
                color: #667eea;
            }

            .btn-copy {
                padding: 6px 12px;
                background: #667eea;
                color: white;
                border: none;
                border-radius: 6px;
                cursor: pointer;
            }

            .warning {
                color: #856404;
                font-size: 13px;
                margin: 8px 0 0 0;
            }

            .help-text {
                background: #e7f3ff;
                padding: 12px;
                border-radius: 6px;
                margin-top: 16px;
                font-size: 13px;
            }

            .help-text p {
                margin: 4px 0;
            }

            .security-footer {
                padding: 16px 24px;
                background: #f8f9fa;
                border-radius: 0 0 16px 16px;
                display: flex;
                gap: 12px;
                justify-content: flex-end;
            }

            .btn-primary, .btn-secondary {
                padding: 12px 24px;
                border: none;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s;
            }

            .btn-primary {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
            }

            .btn-primary:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
            }

            .btn-secondary {
                background: #e0e0e0;
                color: #333;
            }

            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
        `;

        document.head.appendChild(styles);
    }
}

// =====================================
// Global Functions
// =====================================

const sathiSecurity = new SathiSecurity();

function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    input.type = input.type === 'password' ? 'text' : 'password';
}

function copyRecoveryKey() {
    const text = document.getElementById('recovery-key-text').textContent;
    navigator.clipboard.writeText(text);
    alert('✅ Recovery key copied!');
}

async function createMasterKey() {
    const key1 = document.getElementById('master-key-input').value;
    const key2 = document.getElementById('master-key-confirm').value;
    
    const success = await sathiSecurity.createMasterKey(key1, key2);
    
    if (success) {
        setTimeout(() => {
            closeSecurityModal();
            alert('✅ সাথী সেটআপ সম্পন্ন! এখন অ্যাক্সেস করতে পারবেন।');
        }, 3000);
    }
}

async function verifyAdminAccess() {
    const password = document.getElementById('admin-password-input').value;
    const success = await sathiSecurity.verifyAdminPassword(password);
    
    if (success) {
        closeSecurityModal();
        showAdminPanel();
    } else {
        alert('❌ ভুল admin password!');
    }
}

async function verifyMasterAccess(callback) {
    const key = document.getElementById('master-key-verify-input').value;
    const success = await sathiSecurity.verifyMasterKey(key);
    
    if (success) {
        closeSecurityModal();
        if (callback && window[callback]) {
            window[callback]();
        }
    }
}

function closeSecurityModal() {
    const modals = document.querySelectorAll('.security-modal');
    modals.forEach(modal => modal.remove());
}

function showAdminPanel() {
    alert('✅ Admin Panel Access Granted!\n\nসব সেটিংস এখন অ্যাক্সেসযোগ্য।');
    // Open admin panel
    window.location.hash = '#admin';
}

function accessSathi() {
    sathiSecurity.showMasterKeyPrompt('openSathi');
}

function openSathi() {
    alert('✅ সাথী অ্যাক্সেস granted!');
    window.location.hash = '#sathi';
}

// Export
window.SathiSecurity = sathiSecurity;
