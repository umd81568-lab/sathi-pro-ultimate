/* ===================================
   Sathi - Smart Link Handler
   Intelligent link processing & data extraction
   =================================== */

// Link Handler System
const LinkHandler = {
    // Detect if message contains a link
    detectLink: function(message) {
        const urlRegex = /(https?:\/\/[^\s]+)/gi;
        return message.match(urlRegex);
    },
    
    // Process link and extract information
    processLink: async function(url) {
        try {
            showToast('🔍 লিংক প্রসেস করছি...');
            
            // Try to fetch the URL
            const response = await fetch(url, {
                method: 'GET',
                mode: 'cors'
            }).catch(err => {
                // CORS error - use alternative method
                return this.extractFromUrl(url);
            });
            
            if (response && response.ok) {
                const html = await response.text();
                return this.extractData(html, url);
            } else {
                return this.extractFromUrl(url);
            }
            
        } catch (error) {
            console.error('Link processing error:', error);
            return this.extractFromUrl(url);
        }
    },
    
    // Extract data from HTML
    extractData: function(html, url) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        
        // Extract title
        let title = doc.querySelector('title')?.textContent || 
                   doc.querySelector('h1')?.textContent || 
                   'Unknown Title';
        
        // Extract description
        let description = doc.querySelector('meta[name="description"]')?.content ||
                         doc.querySelector('meta[property="og:description"]')?.content ||
                         doc.querySelector('p')?.textContent?.substring(0, 200) || 
                         'No description available';
        
        // Extract main content
        let content = '';
        const paragraphs = doc.querySelectorAll('p');
        for (let i = 0; i < Math.min(paragraphs.length, 5); i++) {
            content += paragraphs[i].textContent + '\n\n';
        }
        
        return {
            url: url,
            title: title.trim(),
            description: description.trim(),
            content: content.trim(),
            type: this.detectLinkType(url)
        };
    },
    
    // Extract basic info from URL itself
    extractFromUrl: function(url) {
        const urlObj = new URL(url);
        const hostname = urlObj.hostname.replace('www.', '');
        const pathname = urlObj.pathname;
        
        return {
            url: url,
            title: `${hostname} - ${pathname}`,
            description: `লিংক: ${url}`,
            content: `আমি এই লিংকটি দেখেছি। এটি ${hostname} এর একটি পেজ।`,
            type: this.detectLinkType(url)
        };
    },
    
    // Detect type of link
    detectLinkType: function(url) {
        const urlLower = url.toLowerCase();
        
        if (urlLower.includes('youtube.com') || urlLower.includes('youtu.be')) {
            return 'video';
        } else if (urlLower.match(/\.(jpg|jpeg|png|gif|webp)$/)) {
            return 'image';
        } else if (urlLower.match(/\.(pdf)$/)) {
            return 'pdf';
        } else if (urlLower.includes('twitter.com') || urlLower.includes('x.com')) {
            return 'social';
        } else if (urlLower.includes('facebook.com')) {
            return 'social';
        } else if (urlLower.includes('instagram.com')) {
            return 'social';
        } else {
            return 'webpage';
        }
    },
    
    // Generate intelligent response about the link
    generateLinkResponse: async function(linkData, userMessage) {
        const { title, description, content, type, url } = linkData;
        
        let response = '';
        
        // Type-specific responses
        switch(type) {
            case 'video':
                response = `আমি ভিডিওটি দেখেছি! 🎥\n\n`;
                response += `**${title}**\n\n`;
                response += `${description}\n\n`;
                response += `তুমি কি এই ভিডিও সম্পর্কে কিছু জানতে চাও?`;
                break;
                
            case 'image':
                response = `সুন্দর ছবি! 📸 আমি দেখেছি।\n\n`;
                response += `তুমি কি এই ছবি সম্পর্কে কিছু বলতে চাও?`;
                break;
                
            case 'pdf':
                response = `আমি PDF ডকুমেন্টটি দেখেছি! 📄\n\n`;
                response += `এটি সম্পর্কে তুমি কী জানতে চাও?`;
                break;
                
            case 'social':
                response = `আমি সোশ্যাল মিডিয়া পোস্টটি দেখেছি! 📱\n\n`;
                response += `${description}\n\n`;
                response += `তোমার কী মনে হয়?`;
                break;
                
            default:
                response = `আমি লিংকটি দেখেছি! 🔗\n\n`;
                response += `**${title}**\n\n`;
                response += `${description}\n\n`;
                
                if (content && content.length > 50) {
                    response += `মূল বিষয়:\n${content.substring(0, 300)}...\n\n`;
                }
                
                response += `এটি সম্পর্কে তুমি কী জানতে চাও বা কী মনে করো?`;
        }
        
        return response;
    },
    
    // Handle link in conversation
    handleInConversation: async function(message) {
        const links = this.detectLink(message);
        
        if (!links || links.length === 0) {
            return null;
        }
        
        // Process first link
        const url = links[0];
        const linkData = await this.processLink(url);
        const response = await this.generateLinkResponse(linkData, message);
        
        // Store link data in context
        if (!AppState.linkContext) {
            AppState.linkContext = [];
        }
        AppState.linkContext.push(linkData);
        
        // Keep only last 5 links
        if (AppState.linkContext.length > 5) {
            AppState.linkContext = AppState.linkContext.slice(-5);
        }
        
        return response;
    }
};

// Data Modification Handler
const DataModifier = {
    // Detect if user wants to modify something
    detectModificationRequest: function(message) {
        const modKeywords = [
            'পরিবর্তন', 'বদলাও', 'চেঞ্জ', 'change', 'modify', 'update', 
            'এডিট', 'edit', 'ঠিক কর', 'fix', 'সংশোধন'
        ];
        
        return modKeywords.some(keyword => message.toLowerCase().includes(keyword));
    },
    
    // Extract what needs to be modified
    extractModificationIntent: function(message) {
        const intent = {
            target: null,
            value: null,
            type: null
        };
        
        // Check what to modify
        if (message.includes('নাম') || message.includes('name')) {
            intent.type = 'name';
            intent.target = 'companion_name';
        } else if (message.includes('ব্যক্তিত্ব') || message.includes('personality')) {
            intent.type = 'personality';
            intent.target = 'companion_personality';
        } else if (message.includes('থিম') || message.includes('theme')) {
            intent.type = 'theme';
            intent.target = 'app_theme';
        } else if (message.includes('ছবি') || message.includes('avatar') || message.includes('photo')) {
            intent.type = 'avatar';
            intent.target = 'companion_avatar';
        }
        
        return intent;
    },
    
    // Apply modification
    applyModification: function(intent, value) {
        switch(intent.type) {
            case 'name':
                AppState.companion.name = value;
                updateCompanionNameDisplay();
                saveUserData();
                return `✅ নাম পরিবর্তন করা হয়েছে! এখন আমি "${value}"`;
                
            case 'personality':
                const validPersonalities = ['sweet', 'romantic', 'playful', 'caring', 'bold', 'mysterious'];
                if (validPersonalities.includes(value)) {
                    AppState.companion.personality = value;
                    saveUserData();
                    return `✅ ব্যক্তিত্ব পরিবর্তন করা হয়েছে!`;
                }
                return `⚠️ দুঃখিত, "${value}" একটি valid ব্যক্তিত্ব নয়।`;
                
            case 'theme':
                const validThemes = ['romantic', 'ocean', 'sunset', 'dark', 'forest', 'light'];
                if (validThemes.includes(value)) {
                    applyTheme(value);
                    return `✅ থিম পরিবর্তন করা হয়েছে!`;
                }
                return `⚠️ দুঃখিত, "${value}" একটি valid থিম নয়।`;
                
            default:
                return null;
        }
    },
    
    // Interactive modification flow
    startModificationFlow: function(intent) {
        const prompts = {
            'name': 'আমার নতুন নাম কী হবে? 💕',
            'personality': 'কোন ব্যক্তিত্ব চাও? (sweet, romantic, playful, caring, bold, mysterious)',
            'theme': 'কোন থিম চাও? (romantic, ocean, sunset, dark, forest, light)',
            'avatar': 'নতুন ছবি আপলোড করতে Settings > ছবি আপলোড যাও!'
        };
        
        AppState.pendingModification = intent;
        return prompts[intent.type] || 'তুমি কী পরিবর্তন করতে চাও?';
    },
    
    // Handle modification in conversation
    handleModification: function(message) {
        // Check if there's a pending modification
        if (AppState.pendingModification) {
            const intent = AppState.pendingModification;
            const value = message.trim();
            const result = this.applyModification(intent, value);
            AppState.pendingModification = null;
            return result || 'পরিবর্তন সম্পন্ন হয়েছে! ✅';
        }
        
        // Detect new modification request
        if (this.detectModificationRequest(message)) {
            const intent = this.extractModificationIntent(message);
            
            if (intent.type) {
                return this.startModificationFlow(intent);
            } else {
                return 'তুমি কী পরিবর্তন করতে চাও? নাম, ব্যক্তিত্ব, থিম, নাকি ছবি?';
            }
        }
        
        return null;
    }
};

// Enhanced response generator with link & modification support
const originalGenerateResponse = window.generateResponse;

window.generateResponse = async function(userMessage) {
    // First check for links
    const linkResponse = await LinkHandler.handleInConversation(userMessage);
    if (linkResponse) {
        return linkResponse;
    }
    
    // Then check for modifications
    const modResponse = DataModifier.handleModification(userMessage);
    if (modResponse) {
        return modResponse;
    }
    
    // Use original response generator
    return originalGenerateResponse(userMessage);
};

// Update sendMessage to handle async responses
const originalSendMessage = window.sendMessage;

window.sendMessage = async function() {
    const input = document.getElementById('messageInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    // Add user message
    addUserMessage(message);
    
    // Clear input
    input.value = '';
    
    // Show typing indicator
    showTypingIndicator();
    
    // Generate response (now async)
    try {
        const response = await generateResponse(message);
        
        setTimeout(() => {
            hideTypingIndicator();
            addCompanionMessage(response);
            
            // Speak if auto-voice is enabled
            if (AppState.settings.autoVoice) {
                speakText(response);
            }
        }, 1000 + Math.random() * 1500);
    } catch (error) {
        console.error('Response generation error:', error);
        hideTypingIndicator();
        addCompanionMessage('দুঃখিত, একটু সমস্যা হয়েছে। আবার চেষ্টা করো!');
    }
    
    // Update stats
    AppState.stats.totalMessages++;
    AppState.stats.lastActive = new Date().toISOString();
    saveUserData();
};

// Initialize
console.log('✅ Smart Link Handler & Data Modifier loaded successfully');
console.log('🔗 Link detection: Enabled');
console.log('✏️ Data modification: Enabled');
