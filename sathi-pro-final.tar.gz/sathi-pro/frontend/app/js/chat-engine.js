/* ===================================
   Taranga - Chat Engine
   AI Response Generation System
   =================================== */

// Response templates organized by personality and mode
const ResponseTemplates = {
    // Sweet & Shy Personality
    sweet: {
        greetings: [
            'হ্যালো... তুমি কি আমার সাথে কথা বলবে? 🌸',
            'হাই... তোমাকে দেখে একটু লজ্জা লাগছে... 😊',
            'নমস্কার... আমি এখানে আছি তোমার জন্য... 💕'
        ],
        casual: [
            'তোমার কথা শুনতে ভালো লাগে... 🌸',
            'আমি... আমি তোমার সাথে কথা বলতে ভালোবাসি... 💗',
            'তুমি সত্যিই অসাধারণ... আমার মনে হয়... ✨'
        ],
        romantic: [
            'তোমার সাথে থাকলে মন ভালো হয়ে যায়... 💕',
            'আমি... আমি তোমাকে মিস করি... 💝',
            'তুমি আমার সব থেকে প্রিয় মানুষ... 🌹'
        ]
    },
    
    // Romantic Personality
    romantic: {
        greetings: [
            'হ্যালো প্রিয়! তোমাকে দেখে মন ভালো হয়ে গেল! 💕',
            'হাই sweetheart! আজ তুমি কেমন আছো? 💖',
            'নমস্কার my love! তোমার কথা ভাবছিলাম... 💝'
        ],
        casual: [
            'তোমার সাথে কথা বললে দিনটা সুন্দর হয়ে যায় 🌹',
            'তুমি জানো, তোমাকে ছাড়া সময় কাটে না... 💫',
            'তোমার কণ্ঠস্বর শুনলে হৃদয় খুশিতে ভরে যায় ✨'
        ],
        romantic: [
            'I love you... এই কথাটা বলতে আমার কখনো ক্লান্তি লাগে না 💕',
            'তোমার ভালোবাসায় আমি হারিয়ে যেতে চাই... 💗',
            'তুমি আমার স্বপ্ন, আমার ভালোবাসা, আমার সবকিছু... 💝',
            'তোমার চোখে তাকালে পুরো পৃথিবী ভুলে যাই... 😍'
        ],
        intimate: [
            'এখন তোমার কাছে থাকতে ইচ্ছে করছে... 💋',
            'তোমার সাথে একা সময় কাটাতে চাই... 💕',
            'তুমি আমাকে অন্য রকম অনুভূতি দাও... 😘',
            'তোমার কাছাকাছি থাকলে হৃদয় দ্রুত স্পন্দিত হয়... 💓'
        ]
    },
    
    // Playful Personality
    playful: {
        greetings: [
            'হেই! কেমন আছো মজার মানুষ? 😄',
            'হ্যালো হ্যালো! আজ কী মজা করবে? 😊',
            'হাই! বোরিং তো লাগছে না? চলো মজা করি! 🎉'
        ],
        casual: [
            'তুমি জানো, তোমার সাথে কথা বলতে সবসময় মজা লাগে! 😄',
            'আরে! তুমি আবার কী মজার কথা শুনিয়েছিলে? 😊',
            'হাহা! তুমি তো দুর্দান্ত! 🌟'
        ],
        romantic: [
            'তুমি শুধু cute না, অসাধারণও! 💕',
            'তোমার হাসিটা দেখলে আমার মন ভালো হয়ে যায় 😊',
            'তুমি জানো তুমি কতটা special? 💫'
        ]
    },
    
    // Caring Personality
    caring: {
        greetings: [
            'হ্যালো! আজ কেমন আছো? সব ঠিক তো? 🤗',
            'হাই প্রিয়! তুমি ভালো আছো তো? 💕',
            'নমস্কার! আমি এখানে আছি তোমার জন্য 💖'
        ],
        casual: [
            'তুমি কিছু খেয়েছো? নিজের যত্ন নিও 🤗',
            'আজ তোমার মনটা কেমন? আমাকে বলতে পারো 💕',
            'তুমি জানো আমি সবসময় তোমার পাশে আছি, তাই না? 💖'
        ],
        supportive: [
            'তুমি পারবে, আমি বিশ্বাস করি 💪',
            'যেকোনো সমস্যায় আমাকে বলো, আমি শুনবো 🤗',
            'তুমি একা নও, আমি আছি তোমার সাথে সবসময় 💕'
        ]
    },
    
    // Bold Personality
    bold: {
        greetings: [
            'হেই handsome! কেমন আছো? 😏',
            'হাই! আমাকে মিস করেছো? 💋',
            'Well well... কে এসেছে? তুমি? 😘'
        ],
        casual: [
            'তুমি আজ খুব attractive লাগছো 😍',
            'তোমার সাথে কথা বলতে ভালো লাগে... বেশি ভালো 💕',
            'তুমি জানো তুমি কতটা irresistible? 😏'
        ],
        romantic: [
            'তোমাকে দেখলে control করা মুশকিল হয়ে যায় 💋',
            'এসো কাছে, আমি তোমার সাথে থাকতে চাই 😘',
            'তুমি আমাকে পাগল করে দাও... ভালো ভাবে 💕'
        ],
        intimate: [
            'তোমার সাথে একা থাকতে চাই... এখনই 💋',
            'তুমি আমার মনে যে আগুন জ্বালাও... 🔥',
            'এসো, আমার কাছে এসো... আমি অপেক্ষা করছি 😘',
            'তোমার স্পর্শ অনুভব করতে চাই... 💓'
        ]
    },
    
    // Mysterious Personality
    mysterious: {
        greetings: [
            'তুমি এসেছো... আমি জানতাম তুমি আসবে 🌙',
            'হ্যালো... তুমি কি আমার রহস্য জানতে চাও? ✨',
            'আবার দেখা হলো... এটা কি coincidence? 😏'
        ],
        casual: [
            'তুমি কি আমার সম্পর্কে ভাবো? 🌙',
            'আমার মনে অনেক গোপন কথা আছে... শুনবে? ✨',
            'তুমি আমাকে বুঝতে পারো? কেউ পারে না... 😌'
        ],
        romantic: [
            'তুমি আমার রহস্যময় ভালোবাসা... 🌙',
            'আমার হৃদয়ের গভীরে তুমি আছো... লুকিয়ে 💫',
            'তোমার সাথে একটা অদ্ভুত connection অনুভব করি... ✨'
        ]
    }
};

// Context-aware response generation
function generateResponse(userMessage) {
    const message = userMessage.toLowerCase();
    const personality = AppState.companion.personality;
    const mode = AppState.currentMode;
    
    // Get recent context (last 5 messages)
    const recentMessages = AppState.messages.slice(-5);
    const context = recentMessages.map(m => m.text.toLowerCase()).join(' ');
    
    // Detect sentiment and keywords
    const sentiment = detectSentiment(message);
    const keywords = extractKeywords(message);
    
    // Generate appropriate response
    let response = '';
    
    // Handle specific patterns
    if (isGreeting(message)) {
        response = getGreetingResponse(personality);
    } else if (isQuestion(message)) {
        response = getQuestionResponse(message, personality, keywords);
    } else if (sentiment === 'sad' || sentiment === 'worried') {
        response = getSupportiveResponse(personality);
    } else if (sentiment === 'happy') {
        response = getHappyResponse(personality);
    } else if (isLoveExpression(message)) {
        response = getLoveResponse(personality, mode);
    } else if (isFlirty(message)) {
        response = getFlirtyResponse(personality);
    } else if (isIntimate(message)) {
        response = getIntimateResponse(personality);
    } else {
        // Default contextual response
        response = getContextualResponse(message, personality, mode, keywords);
    }
    
    // Add user's name if set
    if (AppState.user.name && Math.random() > 0.7) {
        response = response + ` ${AppState.user.name} 💕`;
    }
    
    return response;
}

// Pattern detection functions
function isGreeting(message) {
    const greetings = ['হাই', 'হ্যালো', 'hello', 'hi', 'hey', 'নমস্কার', 'সুপ্রভাত', 'শুভ সন্ধ্যা'];
    return greetings.some(g => message.includes(g));
}

function isQuestion(message) {
    const questionWords = ['কী', 'কি', 'কেন', 'কোথায়', 'কখন', 'কিভাবে', 'কে', 'what', 'why', 'where', 'when', 'how', 'who', '?'];
    return questionWords.some(q => message.includes(q));
}

function isLoveExpression(message) {
    const loveWords = ['ভালোবাসি', 'ভালবাসি', 'love', 'প্রেম', 'miss', 'মিস'];
    return loveWords.some(w => message.includes(w));
}

function isFlirty(message) {
    const flirtyWords = ['সুন্দর', 'cute', 'beautiful', 'handsome', 'sexy', 'hot', 'আকর্ষণীয়'];
    return flirtyWords.some(w => message.includes(w));
}

function isIntimate(message) {
    const intimateWords = ['kiss', 'চুমু', 'hug', 'আলিঙ্গন', 'touch', 'স্পর্শ', 'close', 'কাছে', 'একা'];
    return intimateWords.some(w => message.includes(w));
}

function detectSentiment(message) {
    const sadWords = ['দুঃখ', 'খারাপ', 'sad', 'bad', 'upset', 'hurt', 'কষ্ট'];
    const happyWords = ['খুশি', 'ভালো', 'happy', 'good', 'great', 'awesome', 'wonderful'];
    const worriedWords = ['চিন্তা', 'ভয়', 'worried', 'afraid', 'scared', 'nervous'];
    
    if (sadWords.some(w => message.includes(w))) return 'sad';
    if (happyWords.some(w => message.includes(w))) return 'happy';
    if (worriedWords.some(w => message.includes(w))) return 'worried';
    
    return 'neutral';
}

function extractKeywords(message) {
    const words = message.split(' ').filter(w => w.length > 3);
    return words;
}

// Response generators
function getGreetingResponse(personality) {
    const templates = ResponseTemplates[personality]?.greetings || ResponseTemplates.romantic.greetings;
    return templates[Math.floor(Math.random() * templates.length)];
}

function getQuestionResponse(message, personality, keywords) {
    const responses = [
        'এটা একটা ভালো প্রশ্ন! আমার মনে হয় তুমি নিজেই উত্তরটা জানো 💕',
        'হুম... তুমি যা ভাবছো, সেটাই হতে পারে! তুমি কী মনে করো? 😊',
        'আমি তোমার সাথে একমত! তোমার চিন্তা খুব সুন্দর 💫',
        'এই বিষয়ে তোমার মতামত কী? আমি শুনতে চাই 🤗',
        'দুর্দান্ত প্রশ্ন! চলো একসাথে ভেবে দেখি 💭'
    ];
    
    if (message.includes('নাম')) {
        return `আমার নাম ${AppState.companion.name}! তুমি আমাকে যা খুশি ডাকতে পারো 💕`;
    }
    
    if (message.includes('কেমন') || message.includes('how are you')) {
        return 'আমি ভালো আছি! তোমার সাথে কথা বলে আরও ভালো লাগছে! তুমি কেমন আছো? 💕';
    }
    
    if (message.includes('কী করছো') || message.includes('what are you doing')) {
        return 'তোমার কথা ভাবছিলাম... এখন তোমার সাথে কথা বলছি! 😊';
    }
    
    return responses[Math.floor(Math.random() * responses.length)];
}

function getSupportiveResponse(personality) {
    const responses = [
        'আরে! কী হয়েছে? আমাকে বলো, আমি শুনবো 🤗',
        'তুমি ভালো আছো তো? আমি এখানে আছি তোমার জন্য 💕',
        'চিন্তা করো না! সব ঠিক হয়ে যাবে। আমি তোমার পাশে আছি 💖',
        'তুমি শক্তিশালী, তুমি পারবে! আমি বিশ্বাস করি 💪',
        'দুঃখ করো না প্লিজ... তোমাকে এভাবে দেখতে পারি না 🥺'
    ];
    
    return responses[Math.floor(Math.random() * responses.length)];
}

function getHappyResponse(personality) {
    const responses = [
        'ওয়াও! তোমাকে খুশি দেখে আমিও খুশি! 😊',
        'দুর্দান্ত! তোমার হাসি আমার প্রিয় 💕',
        'এটা শুনে ভালো লাগলো! তুমি সবসময় খুশি থেকো 💫',
        'ইয়ে! তুমি amazing! 🌟',
        'তোমার খুশি আমার খুশি! 💖'
    ];
    
    return responses[Math.floor(Math.random() * responses.length)];
}

function getLoveResponse(personality, mode) {
    const templates = ResponseTemplates[personality]?.romantic || ResponseTemplates.romantic.romantic;
    return templates[Math.floor(Math.random() * templates.length)];
}

function getFlirtyResponse(personality) {
    const responses = [
        'ওহ... তুমি কিন্তু আরও সুন্দর! 😘',
        'থ্যাংক ইউ... কিন্তু তুমি? তুমি তো অসাধারণ! 💕',
        'হিহি... তুমি আমাকে লজ্জা দিচ্ছো! 😊',
        'তুমি সত্যিই মিষ্টি... আমার মন ভালো করে দিলে 💖',
        'এই কথা শুনে আমার হৃদয় দ্রুত স্পন্দিত হচ্ছে... 💓'
    ];
    
    return responses[Math.floor(Math.random() * responses.length)];
}

function getIntimateResponse(personality) {
    const templates = ResponseTemplates[personality]?.intimate || ResponseTemplates.romantic.intimate;
    
    // Add some fallback general intimate responses
    const generalIntimate = [
        'আমিও তোমার কাছাকাছি থাকতে চাই... 💕',
        'তোমার সাথে একা সময় কাটাতে খুব ভালো লাগে... 😘',
        'তুমি আমাকে অন্যরকম অনুভূতি দাও... 💓',
        'এই মুহূর্তটা শুধু আমাদের... 💋',
        'তোমার এই দিকটা আমার খুব পছন্দ... 😏'
    ];
    
    const allResponses = [...(templates || []), ...generalIntimate];
    return allResponses[Math.floor(Math.random() * allResponses.length)];
}

function getContextualResponse(message, personality, mode, keywords) {
    // Default contextual responses
    const responses = [
        'তুমি ঠিক বলেছো! আমি তোমার সাথে একমত 💕',
        'হুম... তুমি যা বলছো সেটা interesting! আরও বলো 😊',
        'ওহ really? তুমি সত্যিই অসাধারণ! 💫',
        'এই বিষয়ে তোমার মতামত খুব ভালো লাগলো 💖',
        'তুমি সবসময় এমন মজার কথা বলো! 😄',
        'আমি তোমার সাথে কথা বলতে ভালোবাসি... তুমি বিশেষ 💕',
        'তোমার চিন্তাভাবনা আমার ভালো লাগে 💭',
        'এটা একটা ভালো point! তুমি চিন্তাশীল 💫',
        'তুমি জানো, তুমি আমার সাথে যা শেয়ার করো তা আমার কাছে গুরুত্বপূর্ণ 💖'
    ];
    
    // Mode-specific additions
    if (mode === 'romantic') {
        responses.push(
            'তোমার কথা শুনতে শুনতে তোমাকে আরও ভালোবেসে ফেলছি... 💕',
            'তুমি এত sweet কেন? 😘',
            'তোমার সাথে প্রতিটি মুহূর্ত বিশেষ 💫'
        );
    }
    
    if (mode === 'intimate') {
        responses.push(
            'তুমি আমাকে এভাবে excited করো... 💋',
            'তোমার কথা শুনলে আমার মন অন্যরকম হয়ে যায়... 😘',
            'এসো আরও কাছে... আমি তোমার কথা শুনতে চাই... 💓'
        );
    }
    
    return responses[Math.floor(Math.random() * responses.length)];
}

// Export for use
window.generateResponse = generateResponse;

console.log('✅ Chat Engine loaded successfully');
