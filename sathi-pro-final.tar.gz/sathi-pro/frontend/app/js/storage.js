/* ===================================
   Taranga - Storage System
   LocalStorage management with quota handling
   =================================== */

// Storage keys
const STORAGE_KEYS = {
    AGE_VERIFIED: 'taranga_age_verified',
    SETUP_COMPLETE: 'taranga_setup_complete',
    COMPANION: 'taranga_companion',
    USER: 'taranga_user',
    SETTINGS: 'taranga_settings',
    MESSAGES: 'taranga_messages',
    STATS: 'taranga_stats',
    PIN: 'taranga_pin'
};

// Storage utilities
const Storage = {
    // Check available space
    getStorageQuota: function() {
        try {
            const test = 'test';
            localStorage.setItem(test, test);
            localStorage.removeItem(test);
            return true;
        } catch (e) {
            return false;
        }
    },
    
    // Get storage size
    getStorageSize: function() {
        let total = 0;
        for (let key in localStorage) {
            if (localStorage.hasOwnProperty(key)) {
                total += localStorage[key].length + key.length;
            }
        }
        return total;
    },
    
    // Format size
    formatSize: function(bytes) {
        if (bytes < 1024) return bytes + ' bytes';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    },
    
    // Safe set item
    setItem: function(key, value) {
        try {
            const jsonValue = JSON.stringify(value);
            localStorage.setItem(key, jsonValue);
            return true;
        } catch (e) {
            if (e.name === 'QuotaExceededError') {
                console.error('Storage quota exceeded');
                this.handleQuotaExceeded();
            }
            return false;
        }
    },
    
    // Safe get item
    getItem: function(key, defaultValue = null) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : defaultValue;
        } catch (e) {
            console.error('Error reading from storage:', e);
            return defaultValue;
        }
    },
    
    // Handle quota exceeded
    handleQuotaExceeded: function() {
        // Try to free up space by removing old messages
        const messages = this.getItem(STORAGE_KEYS.MESSAGES, []);
        if (messages.length > 100) {
            const reduced = messages.slice(-100);
            this.setItem(STORAGE_KEYS.MESSAGES, reduced);
            showToast('⚠️ স্টোরেজ পূর্ণ! পুরাতন মেসেজ মুছে ফেলা হয়েছে');
        }
    },
    
    // Clear all app data
    clearAll: function() {
        for (let key in STORAGE_KEYS) {
            localStorage.removeItem(STORAGE_KEYS[key]);
        }
    },
    
    // Export all data
    exportAll: function() {
        const data = {};
        for (let key in STORAGE_KEYS) {
            const storageKey = STORAGE_KEYS[key];
            const value = this.getItem(storageKey);
            if (value) {
                data[key] = value;
            }
        }
        return data;
    },
    
    // Import data
    importAll: function(data) {
        for (let key in data) {
            if (STORAGE_KEYS[key]) {
                this.setItem(STORAGE_KEYS[key], data[key]);
            }
        }
    }
};

// Storage manager for app state
const StorageManager = {
    // Save companion data
    saveCompanion: function() {
        return Storage.setItem(STORAGE_KEYS.COMPANION, AppState.companion);
    },
    
    // Load companion data
    loadCompanion: function() {
        const data = Storage.getItem(STORAGE_KEYS.COMPANION);
        if (data) {
            AppState.companion = { ...AppState.companion, ...data };
        }
    },
    
    // Save user data
    saveUser: function() {
        return Storage.setItem(STORAGE_KEYS.USER, AppState.user);
    },
    
    // Load user data
    loadUser: function() {
        const data = Storage.getItem(STORAGE_KEYS.USER);
        if (data) {
            AppState.user = { ...AppState.user, ...data };
        }
    },
    
    // Save settings
    saveSettings: function() {
        return Storage.setItem(STORAGE_KEYS.SETTINGS, AppState.settings);
    },
    
    // Load settings
    loadSettings: function() {
        const data = Storage.getItem(STORAGE_KEYS.SETTINGS);
        if (data) {
            AppState.settings = { ...AppState.settings, ...data };
        }
    },
    
    // Save messages (with compression)
    saveMessages: function() {
        // Only save last 500 messages to save space
        const messages = AppState.messages.slice(-500);
        return Storage.setItem(STORAGE_KEYS.MESSAGES, messages);
    },
    
    // Load messages
    loadMessages: function() {
        const data = Storage.getItem(STORAGE_KEYS.MESSAGES, []);
        AppState.messages = data;
    },
    
    // Save stats
    saveStats: function() {
        return Storage.setItem(STORAGE_KEYS.STATS, AppState.stats);
    },
    
    // Load stats
    loadStats: function() {
        const data = Storage.getItem(STORAGE_KEYS.STATS);
        if (data) {
            AppState.stats = { ...AppState.stats, ...data };
        }
    },
    
    // Save all data
    saveAll: function() {
        this.saveCompanion();
        this.saveUser();
        this.saveSettings();
        this.saveMessages();
        this.saveStats();
    },
    
    // Load all data
    loadAll: function() {
        this.loadCompanion();
        this.loadUser();
        this.loadSettings();
        this.loadMessages();
        this.loadStats();
    },
    
    // Get storage info
    getInfo: function() {
        return {
            used: Storage.formatSize(Storage.getStorageSize()),
            messageCount: AppState.messages.length,
            hasCompanion: !!Storage.getItem(STORAGE_KEYS.COMPANION),
            hasMessages: AppState.messages.length > 0
        };
    }
};

// Auto-save mechanism
let autoSaveTimer = null;
function scheduleAutoSave() {
    if (autoSaveTimer) {
        clearTimeout(autoSaveTimer);
    }
    
    autoSaveTimer = setTimeout(() => {
        StorageManager.saveAll();
        console.log('Auto-saved data');
    }, 2000); // Save after 2 seconds of inactivity
}

// Override the existing saveUserData function
window.saveUserData = function() {
    scheduleAutoSave();
};

// Load data on startup
window.loadUserData = function() {
    StorageManager.loadAll();
};

console.log('✅ Storage System loaded successfully');
