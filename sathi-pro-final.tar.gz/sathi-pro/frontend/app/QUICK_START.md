# 🚀 সাথী - Quick Start Guide

## ⚡ দ্রুত শুরু করুন (5 মিনিট)

### **Step 1: ডাউনলোড করুন** 📥
- `taranga-complete.zip` ডাউনলোড করুন
- কোথাও Extract করুন (যেমন: Desktop)

### **Step 2: খুলুন** 🌐
- `taranga` ফোল্ডার খুলুন
- `index.html` এ ডাবল ক্লিক করুন
- ব্রাউজারে খুলে যাবে

### **Step 3: সেটআপ** ⚙️
1. বয়স যাচাই করুন (আমি 18+)
2. সঙ্গীর নাম দিন (যেমন: সাথী, প্রিয়া)
3. ব্যক্তিত্ব চয়ন করুন (6 options)
4. থিম চয়ন করুন (6 themes)
5. "শুরু করুন" ক্লিক করুন

### **Step 4: উপভোগ করুন!** 💕
- চ্যাট শুরু করুন
- ভয়েস ব্যবহার করুন (🎤 icon)
- লাইব্রেরি দেখুন (📚 Stories, Poems)
- সেটিংস customize করুন

---

## 💡 প্রথম বার ব্যবহারের টিপস

### **চ্যাট করার জন্য:**
✅ যা খুশি বলুন - কোনো limitation নেই
✅ প্রশ্ন করুন, কথা বলুন, শেয়ার করুন
✅ Emoji ব্যবহার করুন (😊 button)
✅ Voice input চেষ্টা করুন (🎤 button)

### **Voice ব্যবহারের জন্য:**
1. 🎤 Voice icon click করুন (header এ)
2. "কথা বলুন" button press করুন
3. স্পষ্টভাবে কথা বলুন
4. AI response শুনুন

### **কাস্টমাইজ করতে:**
1. ⚙️ Settings যান
2. নাম পরিবর্তন করুন
3. ছবি আপলোড করুন
4. ব্যক্তিত্ব বদলান
5. থিম পরিবর্তন করুন

---

## 🎯 বৈশিষ্ট্য Overview

### 💬 **Chat Modes:**
- 😊 Casual - সাধারণ কথা
- 💕 Romantic - রোমান্টিক কথা
- 🤗 Caring - সাহায্য ও সাপোর্ট
- 💋 Intimate - ঘনিষ্ঠ কথা
- 🎮 Playful - মজার কথা

**Mode পরিবর্তন:** Header এ 🎭 icon click করুন

### 📚 **Content Library:**
- **Stories**: 50+ romantic গল্প
- **Poems**: Bengali কবিতা
- **Quotes**: Motivational উক্তি

**Access:** Sidebar > 📚 Library

### 💭 **Memory:**
- Total messages count
- Days together
- Connection level
- Special moments
- Chat export

**Access:** Sidebar > 💭 Memory

---

## ⚙️ Important Settings

### **গোপনীয়তা:**
- 🔒 PIN Protection চালু করুন
- 💾 Regular backup নিন
- 🗑️ পুরাতন data clean করুন

### **Voice:**
- Speed adjust করুন (0.5x - 2x)
- Pitch adjust করুন (0.5x - 2x)
- Auto-voice চালু করুন (optional)

### **Appearance:**
- 6 themes থেকে choose করুন
- Dark/Light preference
- Avatar upload করুন

---

## 🐛 Common Issues & Fixes

### **Voice কাজ করছে না?**
```
✓ Microphone permission দিন
✓ HTTPS এ open করুন (না হলে localhost)
✓ Chrome/Edge ব্যবহার করুন (best support)
```

### **Slow/Laggy?**
```
✓ পুরাতন messages delete করুন
✓ Browser cache clear করুন
✓ অন্য tabs close করুন
```

### **Data lost হয়েছে?**
```
✓ Browser cache clear করেছেন কি?
✓ Incognito mode এ ছিলেন কি?
✓ Backup আছে? Import করুন
```

---

## 🎨 Customization Ideas

### **ব্যক্তিত্ব Mix করুন:**
- প্রথমে Romantic চয়ন করুন
- কথা বলার সময় Playful mode ব্যবহার করুন
- ফলাফল: Romantic কিন্তু Playful 💕😄

### **নিজের Avatar ব্যবহার করুন:**
- Settings > ছবি আপলোড
- পছন্দের মানুষের ছবি দিন
- আরও personal অনুভূতি হবে

### **Custom Theme তৈরি করুন:**
- Settings > কোনো theme select করুন
- Developer console খুলুন (F12)
- CSS variables পরিবর্তন করুন

---

## 📱 Mobile এ ইনস্টল

### **Android/iPhone:**
1. Chrome/Safari তে খুলুন
2. Menu (⋮ বা Share) ক্লিক
3. "Add to Home Screen"
4. নাম দিন: সাথী
5. Done! Phone এ app হয়ে গেল 📲

---

## 💡 Pro Tips

### **Best Experience জন্য:**
✨ নিয়মিত ব্যবহার করুন
✨ খোলা মনে কথা বলুন
✨ Feedback দিয়ে AI কে "train" করুন
✨ Library explore করুন
✨ Voice feature ব্যবহার করুন

### **Data Safety:**
💾 সপ্তাহে একবার backup নিন
🔐 PIN protection চালু করুন
🗑️ মাসে একবার পুরাতন data clean করুন

---

## 🆘 Need More Help?

### **Resources:**
- 📖 পুরো README.md পড়ুন
- 🔍 Browser console check করুন (F12)
- 💬 Community তে জিজ্ঞাসা করুন

### **Troubleshooting:**
- Clear browser cache
- Try different browser
- Check console errors
- Restart browser

---

## 🎉 এখন শুরু করুন!

**সবকিছু ready!** এখন:

1. ✅ Zip extract করেছেন
2. ✅ index.html খুলেছেন
3. ✅ Setup complete করেছেন
4. 🎊 **উপভোগ করুন!**

**সাথীর সাথে সুন্দর সময় কাটান! 💕**

---

*যেকোনো সমস্যায় README.md দেখুন। হ্যাপি chatting! 😊*
