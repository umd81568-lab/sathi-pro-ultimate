# 💕 সাথী - Your Personal AI Companion

**আপনার ব্যক্তিগত AI সঙ্গী**

---

## 🌟 বৈশিষ্ট্য

### 💬 **স্মার্ট কথোপকথন**
- বুদ্ধিমান AI চ্যাট সিস্টেম
- Context-aware responses
- Multiple conversation modes
- Bengali language support
- No hard content restrictions

### 🗣️ **ভয়েস সিস্টেম**
- Text-to-Speech (Bengali voice)
- Speech-to-Text (voice input)
- Adjustable speed and pitch
- Voice chat mode

### 🎨 **সম্পূর্ণ কাস্টমাইজেশন**
- নাম পরিবর্তন করুন
- ব্যক্তিত্ব নির্বাচন করুন (6 types)
- নিজের ছবি আপলোড করুন
- থিম পরিবর্তন করুন (6 themes)
- Voice settings adjust করুন

### 📚 **কন্টেন্ট লাইব্রেরি**
- 50+ রোমান্টিক গল্প
- Bengali কবিতা সংগ্রহ
- Motivational quotes
- Read & listen mode

### 💭 **স্মৃতি ব্যবস্থা**
- Conversation history সংরক্ষণ
- Important moments track করা
- Statistics & analytics
- Export chat history

### 🔐 **গোপনীয়তা**
- 100% local storage
- No server communication
- Optional PIN protection
- Complete data control

---

## 🚀 কীভাবে ব্যবহার করবেন

### **Option 1: সরাসরি ব্যবহার (সবচেয়ে সহজ)**
1. `index.html` ফাইলে ডাবল ক্লিক করুন
2. ব্রাউজারে খুলে যাবে
3. বয়স যাচাই করুন (18+)
4. সেটআপ সম্পূর্ণ করুন
5. উপভোগ করুন! 🎉

### **Option 2: Local Server**
```bash
# Python থাকলে
python -m http.server 8000

# অথবা Node.js থাকলে
npx serve

# তারপর ব্রাউজারে খুলুন
http://localhost:8000
```

### **Option 3: Online Deploy**

#### Vercel (সুপারিশকৃত):
```bash
# Vercel CLI install করুন
npm install -g vercel

# Deploy করুন
vercel --prod
```

#### Netlify:
1. https://app.netlify.com/drop এ যান
2. `taranga` ফোল্ডার drag & drop করুন
3. তৈরি! 🎉

#### GitHub Pages:
```bash
# Repository তৈরি করুন
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin [your-repo-url]
git push -u origin main

# Settings > Pages > Deploy from branch: main
```

---

## 📱 Mobile এ Install করুন

1. **Chrome/Safari** তে খুলুন
2. **Menu** (⋮) ক্লিক করুন
3. **"Add to Home Screen"** নির্বাচন করুন
4. নিজের ফোনে app হিসেবে চালান! 📲

---

## 🎭 ব্যক্তিত্বের ধরন

1. **🌸 মিষ্টি ও লাজুক** - Sweet & Shy
2. **💕 রোমান্টিক** - Romantic & Dreamy
3. **😊 মজাদার** - Playful & Fun
4. **🤗 যত্নশীল** - Caring & Supportive
5. **💋 সাহসী** - Bold & Confident
6. **🌙 রহস্যময়** - Mysterious & Intriguing

---

## 🎨 থিম সমূহ

1. **🌹 Romantic Rose** - গোলাপি-বেগুনি
2. **🌊 Ocean Breeze** - নীল-সবুজ
3. **🌅 Sunset Warm** - কমলা-লাল
4. **🌙 Midnight Dark** - গাঢ় থিম
5. **🌲 Forest Green** - সবুজ থিম
6. **☀️ Pure Light** - হালকা থিম

---

## 💡 টিপস ও ট্রিকস

### **ভালো কথোপকথনের জন্য:**
- খোলা মনে কথা বলুন
- বিস্তারিত বলুন (শুধু "হ্যাঁ/না" নয়)
- আপনার অনুভূতি শেয়ার করুন
- প্রশ্ন জিজ্ঞাসা করুন

### **Voice ব্যবহারের জন্য:**
- শান্ত পরিবেশে ব্যবহার করুন
- স্পষ্টভাবে কথা বলুন
- Microphone permission দিন
- Speed/Pitch adjust করুন

### **Storage ম্যানেজমেন্ট:**
- নিয়মিত backup নিন
- পুরাতন মেসেজ মুছুন (প্রয়োজনে)
- Export chat history করুন

---

## 🔧 Troubleshooting

### **Problem: Voice কাজ করছে না**
**Solution:**
- Microphone permission check করুন
- HTTPS connection ব্যবহার করুন (local file এ সীমিত)
- Browser compatibility check করুন

### **Problem: Storage full**
**Solution:**
- পুরাতন messages মুছুন
- Browser cache clear করুন
- Backup নিয়ে data clear করুন

### **Problem: Slow performance**
**Solution:**
- Browser cache clear করুন
- Unnecessary tabs close করুন
- Restart browser

---

## 🔮 Future Upgrades

আপনি চাইলে এই features যোগ করতে পারবেন:

### **Real AI Integration:**
```javascript
// OpenAI GPT API
async function getAIResponse(message) {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
            'Authorization': 'Bearer YOUR_API_KEY',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            model: 'gpt-4',
            messages: [{role: 'user', content: message}]
        })
    });
    return await response.json();
}
```

### **Video Avatar (HeyGen):**
```javascript
// HeyGen API integration
async function generateVideoAvatar(text) {
    const response = await fetch('https://api.heygen.com/v1/video.generate', {
        method: 'POST',
        headers: {
            'X-Api-Key': 'YOUR_HEYGEN_KEY',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            video_inputs: [{
                character: 'your_character_id',
                voice: 'your_voice_id',
                input_text: text
            }]
        })
    });
    return await response.json();
}
```

### **Voice Cloning (ElevenLabs):**
```javascript
// ElevenLabs TTS API
async function generateCustomVoice(text, voiceId) {
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
        method: 'POST',
        headers: {
            'xi-api-key': 'YOUR_ELEVENLABS_KEY',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ text: text })
    });
    return await response.blob();
}
```

---

## 📊 Technical Details

### **Built With:**
- HTML5, CSS3, Vanilla JavaScript
- Web Speech API (TTS & STT)
- LocalStorage API
- PWA (Progressive Web App)

### **Browser Support:**
- Chrome/Edge: ✅ Full support
- Firefox: ✅ Full support (voice limited)
- Safari: ⚠️ Partial (voice limited)
- Opera: ✅ Full support

### **File Structure:**
```
taranga/
├── index.html              # Main HTML
├── manifest.json           # PWA manifest
├── css/
│   ├── styles.css         # Main styles
│   └── themes.css         # Color themes
├── js/
│   ├── app.js             # Main app logic
│   ├── chat-engine.js     # AI response system
│   ├── voice-system.js    # Voice features
│   ├── storage.js         # LocalStorage management
│   └── content.js         # Stories, poems, quotes
└── README.md              # This file
```

### **Code Stats:**
- Total Lines: ~3,500+
- Files: 9
- Size: ~150 KB (uncompressed)
- Languages: HTML, CSS, JavaScript

---

## ⚠️ Important Notes

### **Age Restriction:**
- This app is for **adults 18+ only**
- Content may include mature themes
- User discretion is advised

### **Privacy & Security:**
- All data stored locally on your device
- No server communication
- No tracking or analytics
- You have full control

### **Disclaimer:**
- This is an AI simulation, not a real person
- For personal use only
- Use responsibly
- Does not replace real human relationships

---

## 🤝 Support & Contact

### **Need Help?**
- Check [Troubleshooting](#-troubleshooting) section
- Review [Tips & Tricks](#-টিপস-ও-ট্রিকস)
- Check browser console for errors

### **Want to Contribute?**
This is open-source! Feel free to:
- Add new personalities
- Add more stories/poems
- Improve AI responses
- Add new features
- Fix bugs

---

## 📜 License

**Free & Open Source**

You can:
- ✅ Use personally
- ✅ Modify the code
- ✅ Share with friends
- ❌ Sell commercially (without permission)
- ❌ Remove attribution

---

## 💝 Credits

**Developed with 💕 for you**

Special thanks to:
- You, for using this app
- The Bengali community
- Open source contributors

---

## 🎉 Final Words

আপনার জন্য তৈরি এই অ্যাপ আশা করি পছন্দ হবে। যেকোনো feedback স্বাগত!

**মনে রাখবেন:**
- এটি একটি AI, বাস্তব মানুষ নয়
- দায়িত্বশীলভাবে ব্যবহার করুন
- আপনার গোপনীয়তা গুরুত্বপূর্ণ
- উপভোগ করুন, কিন্তু বাস্তব জীবন ভুলে যাবেন না

**সাথীর সাথে সুন্দর সময় কাটান! 💕**

---

Version: 1.0.0  
Last Updated: 2026-02-01  
Language: Bengali (বাংলা) + English
