/**
 * সাথী Cloud Sync System
 * Features:
 * - Auto backup every 5 minutes
 * - Real-time sync
 * - Offline support
 * - Multi-device sync
 */

class SathiCloud {
    constructor(apiUrl = 'http://localhost:8000') {
        this.apiUrl = apiUrl;
        this.token = localStorage.getItem('sathi_token');
        this.syncInterval = null;
        this.offlineQueue = [];
    }

    // =====================================
    // Authentication
    // =====================================

    async register(username, password) {
        try {
            const response = await fetch(`${this.apiUrl}/auth/register`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();

            if (data.success) {
                this.token = data.token;
                localStorage.setItem('sathi_token', this.token);
                this.startAutoSync();
                return { success: true };
            }

            return { success: false, error: data.detail };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    async login(username, password) {
        try {
            const response = await fetch(`${this.apiUrl}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();

            if (data.success) {
                this.token = data.token;
                localStorage.setItem('sathi_token', this.token);
                this.startAutoSync();
                
                // Sync data from cloud
                await this.syncFromCloud();
                
                return { success: true };
            }

            return { success: false, error: data.detail };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    logout() {
        this.token = null;
        localStorage.removeItem('sathi_token');
        this.stopAutoSync();
    }

    isLoggedIn() {
        return !!this.token;
    }

    // =====================================
    // Chat
    // =====================================

    async sendMessage(message, context = {}) {
        try {
            const response = await fetch(`${this.apiUrl}/chat/message`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.token}`
                },
                body: JSON.stringify({ message, context })
            });

            const data = await response.json();

            if (data.success) {
                return {
                    success: true,
                    response: data.response,
                    emotion: data.emotion_analysis
                };
            }

            return { success: false, error: 'Failed to get response' };
        } catch (error) {
            // Offline mode - queue message
            this.offlineQueue.push({ type: 'message', data: { message, context } });
            
            // Local response
            return {
                success: true,
                response: 'আমি এখন অফলাইন মোডে আছি। অনলাইন হলে তোমার কথা মনে রাখব। 💙',
                offline: true
            };
        }
    }

    async getChatHistory(limit = 50) {
        try {
            const response = await fetch(`${this.apiUrl}/chat/history?limit=${limit}`, {
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });

            const data = await response.json();
            return data.success ? data.history : [];
        } catch (error) {
            console.error('Failed to fetch history:', error);
            return [];
        }
    }

    // =====================================
    // Memory
    // =====================================

    async addMemory(memoryType, content, importance = 5) {
        try {
            const response = await fetch(`${this.apiUrl}/memory/add`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.token}`
                },
                body: JSON.stringify({
                    memory_type: memoryType,
                    content,
                    importance
                })
            });

            const data = await response.json();
            return data;
        } catch (error) {
            this.offlineQueue.push({
                type: 'memory',
                data: { memory_type: memoryType, content, importance }
            });
            return { success: false, offline: true };
        }
    }

    async getMemories() {
        try {
            const response = await fetch(`${this.apiUrl}/memory/list`, {
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });

            const data = await response.json();
            return data.success ? data.memories : [];
        } catch (error) {
            console.error('Failed to fetch memories:', error);
            return [];
        }
    }

    // =====================================
    // Search
    // =====================================

    async searchWeb(query, searchType = 'general') {
        try {
            const response = await fetch(`${this.apiUrl}/search/web`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.token}`
                },
                body: JSON.stringify({ query, search_type: searchType })
            });

            const data = await response.json();
            return data;
        } catch (error) {
            return {
                success: false,
                error: 'Search failed',
                message: 'আমি এখন সার্চ করতে পারছি না। একটু পরে চেষ্টা করো। 🔍'
            };
        }
    }

    // =====================================
    // Upload
    // =====================================

    async uploadImage(file) {
        try {
            const formData = new FormData();
            formData.append('file', file);

            const response = await fetch(`${this.apiUrl}/upload/image`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`
                },
                body: formData
            });

            const data = await response.json();
            return data;
        } catch (error) {
            return {
                success: false,
                error: 'Upload failed'
            };
        }
    }

    // =====================================
    // Settings
    // =====================================

    async updateSetting(key, value) {
        try {
            const response = await fetch(`${this.apiUrl}/settings/update`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.token}`
                },
                body: JSON.stringify({ key, value })
            });

            const data = await response.json();
            return data;
        } catch (error) {
            return { success: false };
        }
    }

    async getSettings() {
        try {
            const response = await fetch(`${this.apiUrl}/settings/get`, {
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });

            const data = await response.json();
            return data.success ? data.settings : {};
        } catch (error) {
            return {};
        }
    }

    // =====================================
    // Backup & Sync
    // =====================================

    async exportData() {
        try {
            const response = await fetch(`${this.apiUrl}/backup/export`, {
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });

            const data = await response.json();
            
            // Download as JSON
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `sathi_backup_${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            return { success: true };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    async syncFromCloud() {
        try {
            // Get all data from cloud
            const [history, memories, settings] = await Promise.all([
                this.getChatHistory(1000),
                this.getMemories(),
                this.getSettings()
            ]);

            // Merge with local data
            const localHistory = JSON.parse(localStorage.getItem('chatHistory') || '[]');
            const mergedHistory = this.mergeArrays(localHistory, history, 'timestamp');
            localStorage.setItem('chatHistory', JSON.stringify(mergedHistory));

            // Update memories
            localStorage.setItem('cloudMemories', JSON.stringify(memories));

            // Update settings
            Object.entries(settings).forEach(([key, value]) => {
                localStorage.setItem(key, value);
            });

            return { success: true };
        } catch (error) {
            console.error('Sync failed:', error);
            return { success: false };
        }
    }

    async syncToCloud() {
        try {
            // Process offline queue
            while (this.offlineQueue.length > 0) {
                const item = this.offlineQueue.shift();
                
                if (item.type === 'message') {
                    await this.sendMessage(item.data.message, item.data.context);
                } else if (item.type === 'memory') {
                    await this.addMemory(
                        item.data.memory_type,
                        item.data.content,
                        item.data.importance
                    );
                }
            }

            return { success: true };
        } catch (error) {
            console.error('Sync to cloud failed:', error);
            return { success: false };
        }
    }

    startAutoSync() {
        if (this.syncInterval) return;

        // Sync every 5 minutes
        this.syncInterval = setInterval(() => {
            this.syncToCloud();
        }, 5 * 60 * 1000);

        // Initial sync
        this.syncToCloud();
    }

    stopAutoSync() {
        if (this.syncInterval) {
            clearInterval(this.syncInterval);
            this.syncInterval = null;
        }
    }

    // =====================================
    // Utilities
    // =====================================

    mergeArrays(local, remote, keyField) {
        const map = new Map();
        
        [...local, ...remote].forEach(item => {
            const key = item[keyField];
            if (!map.has(key) || new Date(item[keyField]) > new Date(map.get(key)[keyField])) {
                map.set(key, item);
            }
        });
        
        return Array.from(map.values()).sort((a, b) => 
            new Date(a[keyField]) - new Date(b[keyField])
        );
    }
}

// Export
window.SathiCloud = SathiCloud;
