#!/bin/bash

# সাথী Pro - VPS Auto Deploy Script
# Usage: ./deploy.sh

set -e  # Exit on error

echo "🚀 সাথী Pro Deployment শুরু হচ্ছে..."
echo "======================================"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
VPS_IP="207.180.249.220"
VPS_USER="root"
VPS_PASSWORD="MySecurePass2027Strong"
REMOTE_DIR="/root/sathi-pro"

# Check if sshpass is installed
if ! command -v sshpass &> /dev/null; then
    echo -e "${YELLOW}Installing sshpass...${NC}"
    sudo apt-get install -y sshpass
fi

echo -e "${GREEN}✅ Step 1: Packaging files...${NC}"
cd /home/user
tar -czf sathi-pro.tar.gz sathi-pro/
echo "Package created: sathi-pro.tar.gz"

echo -e "${GREEN}✅ Step 2: Uploading to VPS...${NC}"
sshpass -p "$VPS_PASSWORD" scp -o StrictHostKeyChecking=no sathi-pro.tar.gz ${VPS_USER}@${VPS_IP}:${REMOTE_DIR}/

echo -e "${GREEN}✅ Step 3: Installing on VPS...${NC}"
sshpass -p "$VPS_PASSWORD" ssh -o StrictHostKeyChecking=no ${VPS_USER}@${VPS_IP} << 'ENDSSH'
cd /root
tar -xzf sathi-pro.tar.gz
cd sathi-pro

# Install Python dependencies
echo "📦 Installing Python packages..."
apt-get update -qq
apt-get install -y python3-pip >/dev/null 2>&1
pip3 install -q -r backend/requirements.txt

# Kill existing backend (if running)
pkill -f "python3 app.py" || true

# Start backend in background
echo "🚀 Starting backend..."
cd backend
nohup python3 app.py > /var/log/sathi-backend.log 2>&1 &
sleep 3

# Check if running
if pgrep -f "python3 app.py" > /dev/null; then
    echo "✅ Backend started successfully!"
    echo "📍 API: http://207.180.249.220:8000"
else
    echo "❌ Backend failed to start. Check /var/log/sathi-backend.log"
    exit 1
fi

# Nginx setup (optional)
if command -v nginx &> /dev/null; then
    echo "🌐 Configuring Nginx..."
    
    cat > /etc/nginx/sites-available/sathi << 'EOF'
server {
    listen 80;
    server_name 207.180.249.220;

    location /api/ {
        proxy_pass http://localhost:8000/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    location / {
        root /root/sathi-pro/frontend/app;
        index index.html;
        try_files $uri $uri/ /index.html;
    }
}
EOF

    ln -sf /etc/nginx/sites-available/sathi /etc/nginx/sites-enabled/
    nginx -t && systemctl reload nginx
    echo "✅ Nginx configured!"
else
    echo "ℹ️ Nginx not installed. Installing..."
    apt-get install -y nginx
    # Repeat nginx config
fi

ENDSSH

echo ""
echo "======================================"
echo -e "${GREEN}🎉 Deployment Complete!${NC}"
echo ""
echo "📍 Access URLs:"
echo "   Frontend: http://${VPS_IP}"
echo "   Backend:  http://${VPS_IP}:8000"
echo "   API Docs: http://${VPS_IP}:8000/docs"
echo ""
echo "🔍 Check backend logs:"
echo "   ssh root@${VPS_IP}"
echo "   tail -f /var/log/sathi-backend.log"
echo ""
echo "💡 Next steps:"
echo "   1. Open http://${VPS_IP} in browser"
echo "   2. Register new account"
echo "   3. Start chatting!"
echo ""
echo "======================================"
