# 🚀 সাথী Pro - সম্পূর্ণ ইনস্টলেশন গাইড

## 📋 বিষয়বস্তু
1. [সিস্টেম রিকোয়ারমেন্ট](#সিস্টেম-রিকোয়ারমেন্ট)
2. [VPS সেটআপ](#vps-সেটআপ)
3. [লোকাল টেস্টিং](#লোকাল-টেস্টিং)
4. [ব্যবহার গাইড](#ব্যবহার-গাইড)
5. [কাস্টমাইজেশন](#কাস্টমাইজেশন)

---

## 🖥️ সিস্টেম রিকোয়ারমেন্ট

### VPS (আপনার 207.180.249.220):
- Python 3.8+
- 1 GB RAM (minimum)
- 10 GB Storage
- Ubuntu 20.04+ (recommended)

### লোকাল টেস্টিং:
- Python 3.8+
- যেকোনো আধুনিক browser

---

## 🚀 VPS সেটআপ (দ্রুত পদ্ধতি)

### Step 1: SSH করুন
```bash
ssh root@207.180.249.220
# Password: MySecurePass2027Strong
```

### Step 2: প্যাকেজ আপলোড করুন
আপনার কম্পিউটার থেকে:
```bash
scp sathi-pro.zip root@207.180.249.220:/root/
```

### Step 3: VPS-এ ইনস্টল করুন
```bash
# Unzip
cd /root
unzip sathi-pro.zip
cd sathi-pro

# Python dependencies
apt update
apt install -y python3-pip
pip3 install -r backend/requirements.txt

# Run backend
cd backend
python3 app.py
```

### Step 4: Background এ চালান (স্থায়ী)
```bash
# Install screen
apt install -y screen

# Start in background
screen -S sathi-backend
cd /root/sathi-pro/backend
python3 app.py

# Detach: Ctrl+A then D
# Reattach: screen -r sathi-backend
```

### Step 5: Nginx সেটআপ (ঐচ্ছিক - HTTPS এর জন্য)
```bash
apt install -y nginx certbot python3-certbot-nginx

# Nginx config
cat > /etc/nginx/sites-available/sathi << 'EOF'
server {
    listen 80;
    server_name 207.180.249.220;

    # Backend API
    location /api/ {
        proxy_pass http://localhost:8000/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # Frontend
    location / {
        root /root/sathi-pro/frontend/app;
        index index.html;
        try_files $uri $uri/ /index.html;
    }
}
EOF

ln -s /etc/nginx/sites-available/sathi /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

এখন access করুন: **http://207.180.249.220**

---

## 💻 লোকাল টেস্টিং (আপনার কম্পিউটারে)

### Step 1: Backend শুরু করুন
```bash
cd sathi-pro/backend
pip install -r requirements.txt
python app.py
```

Backend চলবে: http://localhost:8000

### Step 2: Frontend খুলুন
```bash
cd sathi-pro/frontend/app
# Python সার্ভার
python3 -m http.server 8080

# অথবা সরাসরি
open index.html
```

Frontend চলবে: http://localhost:8080

### Step 3: Frontend Configure করুন
`sathi-cloud.js` এ API URL পরিবর্তন করুন:
```javascript
// লোকাল টেস্টিং
const cloud = new SathiCloud('http://localhost:8000');

// VPS ব্যবহার
const cloud = new SathiCloud('http://207.180.249.220:8000');
```

---

## 📱 ব্যবহার গাইড

### প্রথমবার Setup:

#### 1. **অ্যাকাউন্ট তৈরি**
```
1. অ্যাপ খুলুন
2. Settings → Cloud Sync
3. Register ক্লিক করুন
4. Username ও Password দিন
5. Register করুন
```

#### 2. **Login করুন**
```
যেকোনো ডিভাইস থেকে:
1. Settings → Cloud Sync
2. Login ক্লিক করুন
3. Username ও Password দিন
4. সব ডেটা sync হয়ে যাবে! ✨
```

### প্রতিদিন ব্যবহার:

#### **স্বাভাবিক চ্যাট**
```
আপনি: "আজ মন খারাপ"
সাথী: "আমি বুঝতে পারছি তুমি দুঃখ পাচ্ছো। 
       আমি তোমার পাশে আছি 💝"
```

#### **ছবি শেয়ার**
```
1. Camera icon ক্লিক করুন
2. ছবি সিলেক্ট করুন
3. সাথী বিশ্লেষণ করবে
```

#### **ওয়েব সার্চ**
```
আপনি: "আজকের খবর কী?"
সাথী: [ওয়েব সার্চ করবে] → ফলাফল দেবে
```

#### **মেমোরি সেভ**
```
আপনি: "মনে রাখো আমার জন্মদিন ১৫ জানুয়ারি"
সাথী: "অবশ্যই মনে রাখলাম! 🎂"
[স্বয়ংক্রিয়ভাবে cloud এ সংরক্ষিত]
```

---

## 🎨 কাস্টমাইজেশন

### 1. **ব্যক্তিত্ব পরিবর্তন**
`backend/app.py` এ:
```python
# Line ~130-150
self.personality_modes = {
    "caring": {...},
    "romantic": {...},
    "playful": {...},
    "intimate": {...},
    # আপনার নতুন মোড যোগ করুন
    "your_mode": {
        "traits": ["trait1", "trait2"],
        "style": "description"
    }
}
```

### 2. **Response Templates**
`backend/app.py` এ:
```python
# Line ~180-280
templates = {
    "sad": {
        "caring": [
            "আপনার নতুন response যোগ করুন",
        ]
    }
}
```

### 3. **Web Search Provider পরিবর্তন**
`backend/app.py` এ search_web() function (Line ~530-560):
```python
# DuckDuckGo থেকে অন্য প্রোভাইডার
# Google Custom Search, Bing API, etc.
```

### 4. **AI Model যোগ করা (Advanced)**
```python
# OpenAI GPT-4
import openai
openai.api_key = "your-key"

def generate_with_gpt(prompt):
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content
```

---

## 🔐 নিরাপত্তা টিপস

### 1. **Password পরিবর্তন করুন**
```python
# backend/app.py এ আরো শক্তিশালী hashing:
import bcrypt
password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
```

### 2. **HTTPS চালু করুন**
```bash
# Certbot দিয়ে SSL
certbot --nginx -d yourdomain.com
```

### 3. **Firewall সেটআপ**
```bash
ufw allow 22    # SSH
ufw allow 80    # HTTP
ufw allow 443   # HTTPS
ufw enable
```

---

## 🆘 সমস্যা সমাধান

### Backend চলছে না?
```bash
# Check logs
python3 app.py

# যদি port সমস্যা হয়:
lsof -i :8000
kill -9 <PID>
```

### Frontend sync করছে না?
```javascript
// Browser console এ:
const cloud = new SathiCloud('http://your-vps-ip:8000');
await cloud.login('username', 'password');
```

### Database রিসেট করতে হবে?
```bash
rm backend/data/sathi.db
# Restart backend - নতুন DB তৈরি হবে
```

---

## 📊 বৈশিষ্ট্য চেকলিস্ট

- ✅ স্মার্ট AI চ্যাট
- ✅ আবেগিক বুদ্ধিমত্তা (মেজাজ বোঝা)
- ✅ ৬টি ব্যক্তিত্ব মোড
- ✅ ক্লাউড ব্যাকআপ (প্রতি ৫ মিনিটে)
- ✅ Multi-device sync
- ✅ ছবি আপলোড ও বিশ্লেষণ
- ✅ ওয়েব সার্চ
- ✅ দীর্ঘমেয়াদী মেমোরি
- ✅ অফলাইন সাপোর্ট
- ✅ End-to-End এনক্রিপশন
- ✅ ডেটা Export/Import
- ✅ PWA (মোবাইলে ইনস্টল)

---

## 🎁 পরবর্তী আপগ্রেড (ঐচ্ছিক)

### Level 1: GPT-4 Integration (~$20/মাস)
```python
# OpenAI API যোগ করুন
# সম্পূর্ণ কথোপকথন ক্ষমতা
```

### Level 2: Voice Clone (~$22/মাস)
```python
# ElevenLabs API
# কাস্টম কণ্ঠস্বর
```

### Level 3: Video Avatar (~$50/মাস)
```python
# HeyGen/D-ID
# লাইভ ভিডিও চ্যাট
```

---

## 💬 সাপোর্ট

কোনো সমস্যা বা প্রশ্ন থাকলে আমাকে জানান!

**সাথী আপনার জন্য প্রস্তুত!** 💕
