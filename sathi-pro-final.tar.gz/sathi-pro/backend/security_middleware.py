"""
সাথী Pro - Advanced Security & Anti-Hacking System
Features:
- IP Blocking & Whitelisting
- Location-based Access Control
- Rate Limiting
- DDoS Protection
- Brute Force Prevention
- SQL Injection Protection
- XSS Protection
- CSRF Protection
- Suspicious Activity Detection
"""

from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse
from datetime import datetime, timedelta
import ipaddress
import asyncio
from collections import defaultdict
import re
import hashlib

class SecurityMiddleware:
    def __init__(self):
        # IP Whitelist (শুধু এই IP গুলো access পাবে)
        self.whitelist = {
            '207.180.249.220',  # আপনার VPS
            '127.0.0.1',        # Localhost
            '::1'               # Localhost IPv6
        }
        
        # IP Blacklist (এই IP গুলো block)
        self.blacklist = set()
        
        # Country Blacklist (এই দেশ থেকে block)
        # খালি = সব দেশ allow, যোগ করুন যেগুলো block করতে চান
        self.blocked_countries = set()
        # উদাহরণ: {'CN', 'RU', 'KP'}  # China, Russia, North Korea
        
        # Rate Limiting
        self.request_counts = defaultdict(list)
        self.max_requests_per_minute = 60
        self.max_requests_per_hour = 1000
        
        # Failed Login Attempts
        self.failed_logins = defaultdict(int)
        self.login_lockout = defaultdict(lambda: None)
        self.max_failed_logins = 5
        self.lockout_duration = timedelta(minutes=30)
        
        # Suspicious Patterns
        self.suspicious_patterns = [
            r'<script.*?>.*?</script>',  # XSS
            r'union.*select',             # SQL Injection
            r'drop.*table',               # SQL Injection
            r'insert.*into',              # SQL Injection
            r'\.\./',                     # Directory Traversal
            r'exec\s*\(',                 # Code Injection
            r'eval\s*\(',                 # Code Injection
        ]
        
        # Attack Log
        self.attack_log = []
        
    async def __call__(self, request: Request, call_next):
        """Main security middleware"""
        
        # Get client IP
        client_ip = self.get_client_ip(request)
        
        # 1. IP Whitelist Check (ঐচ্ছিক - শুধু specific IP allow)
        # if not self.is_whitelisted(client_ip):
        #     return self.block_request("IP not whitelisted", client_ip)
        
        # 2. IP Blacklist Check
        if self.is_blacklisted(client_ip):
            return self.block_request("IP blacklisted", client_ip)
        
        # 3. Location Check (GeoIP - ঐচ্ছিক)
        country = self.get_country(client_ip)
        if country in self.blocked_countries:
            return self.block_request(f"Country blocked: {country}", client_ip)
        
        # 4. Rate Limiting
        if not self.check_rate_limit(client_ip):
            return self.block_request("Rate limit exceeded", client_ip)
        
        # 5. Suspicious Pattern Detection
        if await self.detect_suspicious_activity(request):
            self.blacklist.add(client_ip)
            return self.block_request("Suspicious activity detected", client_ip)
        
        # 6. Process request
        response = await call_next(request)
        
        # 7. Add security headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Content-Security-Policy"] = "default-src 'self'"
        
        return response
    
    def get_client_ip(self, request: Request) -> str:
        """Get real client IP (behind proxy/nginx)"""
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            return forwarded.split(",")[0].strip()
        
        real_ip = request.headers.get("X-Real-IP")
        if real_ip:
            return real_ip
        
        return request.client.host if request.client else "unknown"
    
    def is_whitelisted(self, ip: str) -> bool:
        """Check if IP is in whitelist"""
        return ip in self.whitelist
    
    def is_blacklisted(self, ip: str) -> bool:
        """Check if IP is blacklisted"""
        return ip in self.blacklist
    
    def get_country(self, ip: str) -> str:
        """
        Get country from IP (requires GeoIP database)
        For now, returns 'UNKNOWN'
        
        Production: Install geoip2 library
        pip install geoip2
        Download MaxMind GeoLite2 database
        """
        # Placeholder - production এ GeoIP2 ব্যবহার করুন
        
        # Simple check for known ranges
        try:
            ip_obj = ipaddress.ip_address(ip)
            
            # Private/Local IPs
            if ip_obj.is_private or ip_obj.is_loopback:
                return 'LOCAL'
            
            # আপনি specific country ranges যোগ করতে পারেন
            # উদাহরণ: China ranges, Russia ranges, etc.
            
        except:
            pass
        
        return 'UNKNOWN'
    
    def check_rate_limit(self, ip: str) -> bool:
        """Rate limiting check"""
        now = datetime.now()
        
        # Clean old requests
        self.request_counts[ip] = [
            req_time for req_time in self.request_counts[ip]
            if now - req_time < timedelta(hours=1)
        ]
        
        # Check limits
        recent_requests = [
            req_time for req_time in self.request_counts[ip]
            if now - req_time < timedelta(minutes=1)
        ]
        
        if len(recent_requests) >= self.max_requests_per_minute:
            self.log_attack("Rate limit exceeded (per minute)", ip)
            return False
        
        if len(self.request_counts[ip]) >= self.max_requests_per_hour:
            self.log_attack("Rate limit exceeded (per hour)", ip)
            return False
        
        # Add current request
        self.request_counts[ip].append(now)
        return True
    
    async def detect_suspicious_activity(self, request: Request) -> bool:
        """Detect suspicious patterns in request"""
        
        # Check URL
        url = str(request.url)
        for pattern in self.suspicious_patterns:
            if re.search(pattern, url, re.IGNORECASE):
                self.log_attack(f"Suspicious URL pattern: {pattern}", self.get_client_ip(request))
                return True
        
        # Check query parameters
        for key, value in request.query_params.items():
            for pattern in self.suspicious_patterns:
                if re.search(pattern, str(value), re.IGNORECASE):
                    self.log_attack(f"Suspicious query param: {key}={value}", self.get_client_ip(request))
                    return True
        
        # Check body (if POST)
        if request.method == "POST":
            try:
                body = await request.body()
                body_str = body.decode()
                
                for pattern in self.suspicious_patterns:
                    if re.search(pattern, body_str, re.IGNORECASE):
                        self.log_attack(f"Suspicious body content", self.get_client_ip(request))
                        return True
            except:
                pass
        
        return False
    
    def check_login_attempt(self, ip: str, success: bool) -> bool:
        """Check failed login attempts"""
        
        # Check if locked out
        if ip in self.login_lockout:
            lockout_until = self.login_lockout[ip]
            if lockout_until and datetime.now() < lockout_until:
                return False
        
        if success:
            # Reset failed attempts
            self.failed_logins[ip] = 0
            self.login_lockout[ip] = None
            return True
        
        # Failed login
        self.failed_logins[ip] += 1
        
        if self.failed_logins[ip] >= self.max_failed_logins:
            # Lockout
            self.login_lockout[ip] = datetime.now() + self.lockout_duration
            self.log_attack(f"Too many failed logins - locked out", ip)
            
            # Add to blacklist after 3 lockouts
            if self.failed_logins[ip] >= self.max_failed_logins * 3:
                self.blacklist.add(ip)
                self.log_attack(f"IP blacklisted due to repeated attacks", ip)
            
            return False
        
        return True
    
    def block_request(self, reason: str, ip: str) -> JSONResponse:
        """Block request and return error"""
        self.log_attack(reason, ip)
        
        return JSONResponse(
            status_code=status.HTTP_403_FORBIDDEN,
            content={
                "error": "Access Denied",
                "message": "Your request has been blocked.",
                "timestamp": datetime.now().isoformat()
            }
        )
    
    def log_attack(self, reason: str, ip: str):
        """Log attack attempt"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "ip": ip,
            "reason": reason
        }
        
        self.attack_log.append(log_entry)
        
        # Keep last 1000 logs
        if len(self.attack_log) > 1000:
            self.attack_log.pop(0)
        
        print(f"🚨 SECURITY ALERT: {reason} from {ip}")
    
    def get_attack_log(self, limit: int = 100):
        """Get recent attack log"""
        return self.attack_log[-limit:]
    
    def add_to_whitelist(self, ip: str):
        """Add IP to whitelist"""
        self.whitelist.add(ip)
        print(f"✅ Added to whitelist: {ip}")
    
    def add_to_blacklist(self, ip: str):
        """Add IP to blacklist"""
        self.blacklist.add(ip)
        print(f"🚫 Added to blacklist: {ip}")
    
    def remove_from_blacklist(self, ip: str):
        """Remove IP from blacklist"""
        if ip in self.blacklist:
            self.blacklist.remove(ip)
            print(f"✅ Removed from blacklist: {ip}")

# Global security instance
security = SecurityMiddleware()
