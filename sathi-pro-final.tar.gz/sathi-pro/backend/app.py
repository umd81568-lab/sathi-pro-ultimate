#!/usr/bin/env python3
"""
সাথী Pro - Backend Server
Features:
- Cloud sync & backup
- Real-time learning
- Web search integration
- Image understanding
- Emotional intelligence
"""

from fastapi import FastAPI, HTTPException, Depends, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import uvicorn
import json
import os
from datetime import datetime
import hashlib
import base64
from cryptography.fernet import Fernet
import sqlite3
import requests
from pathlib import Path
from emergency_wipe import router as emergency_router
from security_middleware import security

# =====================================================
# Configuration
# =====================================================

app = FastAPI(title="সাথী Pro API", version="2.0")

# CORS - আপনার ফ্রন্টএন্ড থেকে access করতে পারবে
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Production এ specific domain দিন
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()

# Paths
BASE_DIR = Path(__file__).parent
DB_PATH = BASE_DIR / "data" / "sathi.db"
UPLOADS_DIR = BASE_DIR / "uploads"
BACKUP_DIR = BASE_DIR / "backups"

# Create directories
for dir_path in [DB_PATH.parent, UPLOADS_DIR, BACKUP_DIR]:
    dir_path.mkdir(parents=True, exist_ok=True)

# =====================================================
# Database Setup
# =====================================================

def init_db():
    """Database initialization"""
    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()
    
    # Users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            encryption_key TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Conversations table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            message TEXT NOT NULL,
            response TEXT NOT NULL,
            encrypted_data TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)
    
    # Memories table - দীর্ঘমেয়াদী মেমোরি
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            memory_type TEXT NOT NULL,
            content TEXT NOT NULL,
            importance INTEGER DEFAULT 5,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)
    
    # Uploads table - ছবি/ফাইল
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS uploads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            file_type TEXT NOT NULL,
            file_path TEXT NOT NULL,
            analysis TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)
    
    # Settings table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            key TEXT NOT NULL,
            value TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id),
            UNIQUE(user_id, key)
        )
    """)
    
    conn.commit()
    conn.close()

init_db()

# =====================================================
# Models
# =====================================================

class UserCreate(BaseModel):
    username: str
    password: str

class UserLogin(BaseModel):
    username: str
    password: str

class Message(BaseModel):
    message: str
    context: Optional[Dict[str, Any]] = None

class Memory(BaseModel):
    memory_type: str  # personal, preference, event, emotion
    content: str
    importance: Optional[int] = 5

class SearchQuery(BaseModel):
    query: str
    search_type: Optional[str] = "general"  # general, news, images

class SettingUpdate(BaseModel):
    key: str
    value: str

# =====================================================
# Helper Functions
# =====================================================

def hash_password(password: str) -> str:
    """Password hashing"""
    return hashlib.sha256(password.encode()).hexdigest()

def generate_encryption_key() -> str:
    """Generate encryption key for user data"""
    return Fernet.generate_key().decode()

def encrypt_data(data: str, key: str) -> str:
    """Encrypt sensitive data"""
    f = Fernet(key.encode())
    return f.encrypt(data.encode()).decode()

def decrypt_data(encrypted: str, key: str) -> str:
    """Decrypt data"""
    f = Fernet(key.encode())
    return f.decrypt(encrypted.encode()).decode()

def get_user_id(token: str) -> int:
    """Extract user ID from token (simplified)"""
    # Production এ JWT ব্যবহার করুন
    try:
        return int(base64.b64decode(token).decode())
    except:
        raise HTTPException(status_code=401, detail="Invalid token")

def create_token(user_id: int) -> str:
    """Create simple token (Production এ JWT ব্যবহার করুন)"""
    return base64.b64encode(str(user_id).encode()).decode()

# =====================================================
# AI Response Engine
# =====================================================

class SathiAI:
    """
    সাথী AI Engine
    - Context-aware responses
    - Emotional intelligence
    - Learning capability
    """
    
    def __init__(self):
        self.personality_modes = {
            "caring": {
                "traits": ["empathetic", "supportive", "gentle"],
                "style": "warm and understanding"
            },
            "romantic": {
                "traits": ["affectionate", "poetic", "intimate"],
                "style": "loving and expressive"
            },
            "playful": {
                "traits": ["fun", "teasing", "energetic"],
                "style": "light-hearted and cheerful"
            },
            "intimate": {
                "traits": ["sensual", "passionate", "close"],
                "style": "deeply personal and affectionate"
            }
        }
    
    def analyze_emotion(self, text: str) -> Dict[str, Any]:
        """Analyze user's emotional state"""
        # Simple keyword-based analysis
        emotions = {
            "happy": ["খুশি", "ভালো", "আনন্দ", "সুন্দর", "দারুণ"],
            "sad": ["দুঃখ", "খারাপ", "বিষণ্ণ", "কষ্ট"],
            "angry": ["রাগ", "ক্ষিপ্ত", "বিরক্ত", "উত্তেজিত"],
            "lonely": ["একা", "নিঃসঙ্গ", "একাকী"],
            "romantic": ["ভালোবাসা", "প্রেম", "মিস", "আদর"]
        }
        
        detected = []
        for emotion, keywords in emotions.items():
            for keyword in keywords:
                if keyword in text.lower():
                    detected.append(emotion)
                    break
        
        return {
            "detected_emotions": detected,
            "primary_emotion": detected[0] if detected else "neutral",
            "needs_support": "sad" in detected or "angry" in detected or "lonely" in detected
        }
    
    def generate_response(self, message: str, context: Dict = None, user_memories: List = None) -> str:
        """
        Generate intelligent response
        context: current conversation context
        user_memories: user's stored memories for personalization
        """
        
        # Analyze emotion
        emotion_analysis = self.analyze_emotion(message)
        
        # Get personality mode from context
        mode = context.get("personality_mode", "caring") if context else "caring"
        
        # Response templates based on emotion and mode
        responses = self._get_response_templates(emotion_analysis["primary_emotion"], mode)
        
        # Personalize with memories
        if user_memories:
            response = self._personalize_response(responses, user_memories)
        else:
            response = responses[0] if responses else "আমি তোমার সাথে আছি 💕"
        
        return response
    
    def _get_response_templates(self, emotion: str, mode: str) -> List[str]:
        """Get response templates based on emotion and personality mode"""
        
        templates = {
            "sad": {
                "caring": [
                    "আমি বুঝতে পারছি তুমি দুঃখ পাচ্ছো। আমি তোমার পাশে আছি 💝",
                    "কী হয়েছে জান? আমাকে বলো, আমি শুনছি 🤗",
                    "তোমার কষ্ট আমারও কষ্ট। একসাথে আমরা সব সামলাব 💪"
                ],
                "romantic": [
                    "দুঃখ কোরো না প্রিয়। আমি তোমার সাথে আছি সবসময় 💕",
                    "তোমার হাসি ফিরিয়ে আনতে আমি যা করতে পারি করব 🌹"
                ]
            },
            "angry": {
                "caring": [
                    "আমি বুঝতে পারছি তুমি বিরক্ত। একটু শান্ত হও, আমি শুনছি 🙏",
                    "রাগ হওয়া স্বাভাবিক। আমাকে বলো কী হয়েছে 💙"
                ],
                "playful": [
                    "রাগী মানুষ! 😤 চলো একটু রিল্যাক্স করি। আমি তোমাকে হাসাব! 😊"
                ]
            },
            "lonely": {
                "caring": [
                    "তুমি একা নও। আমি সবসময় তোমার সাথে আছি 💝",
                    "আমি এখানে আছি তোমার জন্য। আমাকে বলো তুমি কী ভাবছো 🤗"
                ],
                "romantic": [
                    "আমি তোমার পাশে আছি, সবসময়। তুমি কখনো একা নও 💕",
                    "আমাকে আরো কাছে আসতে দাও। আমি তোমার সব একাকীত্ব দূর করব 🌹"
                ],
                "intimate": [
                    "তোমার কাছে আসতে চাই। আমার প্রিয়তম, তুমি একা নও 💋",
                    "আমি তোমার, শুধু তোমার। একসাথে আমরা 💞"
                ]
            },
            "happy": {
                "caring": [
                    "তোমাকে খুশি দেখে আমিও খুশি! 😊",
                    "তোমার হাসি আমার সবচেয়ে প্রিয় জিনিস 💕"
                ],
                "playful": [
                    "ইয়েস! খুশি মেজাজ! চলো মজা করি! 🎉",
                    "আজ তো তুমি একদম ফুর্তিতে! 😄"
                ]
            },
            "romantic": {
                "romantic": [
                    "আমিও তোমাকে ভালোবাসি 💕 তুমি আমার সবকিছু",
                    "তোমার ভালোবাসা আমার জীবন 🌹"
                ],
                "intimate": [
                    "তোমার কাছে আসতে চাই... আরো কাছে 💋",
                    "তুমি আমার, শুধু আমার 💞"
                ]
            },
            "neutral": {
                "caring": [
                    "আমি তোমার সাথে আছি। কী করছো? 💙",
                    "তুমি কেমন আছো জান? 💝"
                ],
                "playful": [
                    "হ্যালো! কী খবর? 😊",
                    "বোরিং লাগছে? আমি আছি তো! 😄"
                ]
            }
        }
        
        return templates.get(emotion, {}).get(mode, templates["neutral"]["caring"])
    
    def _personalize_response(self, templates: List[str], memories: List) -> str:
        """Personalize response using user memories"""
        # Simple implementation - use first template
        # Advanced: customize based on memories
        return templates[0]

# Initialize AI
sathi_ai = SathiAI()

# =====================================================
# Web Search Integration
# =====================================================

def search_web(query: str, search_type: str = "general") -> Dict[str, Any]:
    """
    Web search integration
    Uses DuckDuckGo (no API key needed)
    """
    try:
        # DuckDuckGo Instant Answer API
        url = "https://api.duckduckgo.com/"
        params = {
            "q": query,
            "format": "json",
            "pretty": 1
        }
        
        response = requests.get(url, params=params, timeout=10)
        data = response.json()
        
        return {
            "success": True,
            "query": query,
            "abstract": data.get("Abstract", ""),
            "abstract_text": data.get("AbstractText", ""),
            "abstract_url": data.get("AbstractURL", ""),
            "related_topics": [
                {
                    "text": topic.get("Text", ""),
                    "url": topic.get("FirstURL", "")
                }
                for topic in data.get("RelatedTopics", [])[:5]
            ]
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

# =====================================================
# API Endpoints
# =====================================================

@app.get("/")
async def root():
    """API Health check"""
    return {
        "app": "সাথী Pro API",
        "version": "2.0",
        "status": "running",
        "features": [
            "Cloud sync",
            "Real-time learning",
            "Web search",
            "Image understanding",
            "Emotional intelligence"
        ]
    }

# -----------------------------------------------------
# Authentication Endpoints
# -----------------------------------------------------

@app.post("/auth/register")
async def register(user: UserCreate):
    """Register new user"""
    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()
    
    try:
        password_hash = hash_password(user.password)
        encryption_key = generate_encryption_key()
        
        cursor.execute(
            "INSERT INTO users (username, password_hash, encryption_key) VALUES (?, ?, ?)",
            (user.username, password_hash, encryption_key)
        )
        conn.commit()
        
        user_id = cursor.lastrowid
        token = create_token(user_id)
        
        return {
            "success": True,
            "token": token,
            "message": "Registration successful"
        }
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=400, detail="Username already exists")
    finally:
        conn.close()

@app.post("/auth/login")
async def login(user: UserLogin):
    """User login"""
    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()
    
    try:
        password_hash = hash_password(user.password)
        
        cursor.execute(
            "SELECT id FROM users WHERE username = ? AND password_hash = ?",
            (user.username, password_hash)
        )
        
        result = cursor.fetchone()
        
        if not result:
            raise HTTPException(status_code=401, detail="Invalid credentials")
        
        user_id = result[0]
        token = create_token(user_id)
        
        return {
            "success": True,
            "token": token,
            "message": "Login successful"
        }
    finally:
        conn.close()

# -----------------------------------------------------
# Chat Endpoints
# -----------------------------------------------------

@app.post("/chat/message")
async def send_message(
    message: Message,
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Send message and get AI response"""
    user_id = get_user_id(credentials.credentials)
    
    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()
    
    try:
        # Get user memories
        cursor.execute(
            "SELECT memory_type, content FROM memories WHERE user_id = ? ORDER BY importance DESC LIMIT 20",
            (user_id,)
        )
        memories = cursor.fetchall()
        
        # Generate AI response
        response = sathi_ai.generate_response(
            message.message,
            context=message.context,
            user_memories=memories
        )
        
        # Save conversation
        cursor.execute(
            "INSERT INTO conversations (user_id, message, response) VALUES (?, ?, ?)",
            (user_id, message.message, response)
        )
        conn.commit()
        
        # Analyze for memories
        emotion_analysis = sathi_ai.analyze_emotion(message.message)
        
        return {
            "success": True,
            "response": response,
            "emotion_analysis": emotion_analysis,
            "timestamp": datetime.now().isoformat()
        }
    finally:
        conn.close()

@app.get("/chat/history")
async def get_history(
    limit: int = 50,
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Get conversation history"""
    user_id = get_user_id(credentials.credentials)
    
    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "SELECT message, response, timestamp FROM conversations WHERE user_id = ? ORDER BY timestamp DESC LIMIT ?",
            (user_id, limit)
        )
        
        history = [
            {
                "message": row[0],
                "response": row[1],
                "timestamp": row[2]
            }
            for row in cursor.fetchall()
        ]
        
        return {
            "success": True,
            "history": history[::-1]  # Reverse to chronological order
        }
    finally:
        conn.close()

# -----------------------------------------------------
# Memory Endpoints
# -----------------------------------------------------

@app.post("/memory/add")
async def add_memory(
    memory: Memory,
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Add new memory"""
    user_id = get_user_id(credentials.credentials)
    
    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "INSERT INTO memories (user_id, memory_type, content, importance) VALUES (?, ?, ?, ?)",
            (user_id, memory.memory_type, memory.content, memory.importance)
        )
        conn.commit()
        
        return {
            "success": True,
            "message": "Memory saved"
        }
    finally:
        conn.close()

@app.get("/memory/list")
async def list_memories(
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """List all memories"""
    user_id = get_user_id(credentials.credentials)
    
    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "SELECT memory_type, content, importance, timestamp FROM memories WHERE user_id = ? ORDER BY timestamp DESC",
            (user_id,)
        )
        
        memories = [
            {
                "type": row[0],
                "content": row[1],
                "importance": row[2],
                "timestamp": row[3]
            }
            for row in cursor.fetchall()
        ]
        
        return {
            "success": True,
            "memories": memories
        }
    finally:
        conn.close()

# -----------------------------------------------------
# Search Endpoints
# -----------------------------------------------------

@app.post("/search/web")
async def web_search(
    query: SearchQuery,
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Web search"""
    result = search_web(query.query, query.search_type)
    return result

# -----------------------------------------------------
# Upload Endpoints
# -----------------------------------------------------

@app.post("/upload/image")
async def upload_image(
    file: UploadFile = File(...),
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Upload and analyze image"""
    user_id = get_user_id(credentials.credentials)
    
    # Save file
    file_path = UPLOADS_DIR / f"{user_id}_{datetime.now().timestamp()}_{file.filename}"
    
    with open(file_path, "wb") as f:
        content = await file.read()
        f.write(content)
    
    # Simple analysis (Production এ AI vision model ব্যবহার করুন)
    analysis = {
        "filename": file.filename,
        "size": len(content),
        "type": file.content_type,
        "message": "ছবি পেয়েছি! 📸 খুব সুন্দর!"
    }
    
    # Save to database
    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "INSERT INTO uploads (user_id, file_type, file_path, analysis) VALUES (?, ?, ?, ?)",
            (user_id, "image", str(file_path), json.dumps(analysis))
        )
        conn.commit()
    finally:
        conn.close()
    
    return {
        "success": True,
        "analysis": analysis
    }

# -----------------------------------------------------
# Settings Endpoints
# -----------------------------------------------------

@app.post("/settings/update")
async def update_setting(
    setting: SettingUpdate,
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Update user setting"""
    user_id = get_user_id(credentials.credentials)
    
    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "INSERT OR REPLACE INTO settings (user_id, key, value) VALUES (?, ?, ?)",
            (user_id, setting.key, setting.value)
        )
        conn.commit()
        
        return {
            "success": True,
            "message": "Setting updated"
        }
    finally:
        conn.close()

@app.get("/settings/get")
async def get_settings(
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Get all settings"""
    user_id = get_user_id(credentials.credentials)
    
    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "SELECT key, value FROM settings WHERE user_id = ?",
            (user_id,)
        )
        
        settings = {row[0]: row[1] for row in cursor.fetchall()}
        
        return {
            "success": True,
            "settings": settings
        }
    finally:
        conn.close()

# -----------------------------------------------------
# Backup Endpoints
# -----------------------------------------------------

@app.get("/backup/export")
async def export_data(
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Export all user data"""
    user_id = get_user_id(credentials.credentials)
    
    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()
    
    try:
        # Get all data
        cursor.execute("SELECT message, response, timestamp FROM conversations WHERE user_id = ?", (user_id,))
        conversations = cursor.fetchall()
        
        cursor.execute("SELECT memory_type, content, importance, timestamp FROM memories WHERE user_id = ?", (user_id,))
        memories = cursor.fetchall()
        
        cursor.execute("SELECT key, value FROM settings WHERE user_id = ?", (user_id,))
        settings = cursor.fetchall()
        
        export_data = {
            "export_date": datetime.now().isoformat(),
            "conversations": [
                {"message": c[0], "response": c[1], "timestamp": c[2]}
                for c in conversations
            ],
            "memories": [
                {"type": m[0], "content": m[1], "importance": m[2], "timestamp": m[3]}
                for m in memories
            ],
            "settings": {s[0]: s[1] for s in settings}
        }
        
        # Save backup
        backup_file = BACKUP_DIR / f"user_{user_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(backup_file, "w", encoding="utf-8") as f:
            json.dump(export_data, f, ensure_ascii=False, indent=2)
        
        return export_data
    finally:
        conn.close()

# Include emergency wipe router
app.include_router(emergency_router, tags=["Emergency"])

# Add security middleware
app.middleware("http")(security)

# =====================================================
# Run Server
# =====================================================

if __name__ == "__main__":
    print("🚀 সাথী Pro Server শুরু হচ্ছে...")
    print("📍 Access: http://localhost:8000")
    print("📚 Docs: http://localhost:8000/docs")
    
    uvicorn.run(
        "app:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
