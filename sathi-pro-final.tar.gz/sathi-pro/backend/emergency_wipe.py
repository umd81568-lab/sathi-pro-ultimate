"""
সাথী Pro - Emergency Wipe Endpoint
Server-side data destruction for emergency situations
"""

from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import sqlite3
import shutil
import os
from pathlib import Path
from datetime import datetime

router = APIRouter()
security = HTTPBearer()

# Paths
BASE_DIR = Path(__file__).parent
DB_PATH = BASE_DIR / "data" / "sathi.db"
UPLOADS_DIR = BASE_DIR / "uploads"
BACKUP_DIR = BASE_DIR / "backups"

def get_user_id(token: str) -> int:
    """Extract user ID from token"""
    try:
        import base64
        return int(base64.b64decode(token).decode())
    except:
        raise HTTPException(status_code=401, detail="Invalid token")

@router.post("/emergency/wipe")
async def emergency_wipe(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """
    Emergency data wipe
    Permanently deletes ALL user data:
    - Database entries
    - Uploaded files
    - Backups
    - Logs
    """
    
    try:
        user_id = get_user_id(credentials.credentials)
        
        # Log emergency wipe
        print(f"🚨 EMERGENCY WIPE INITIATED - User ID: {user_id}")
        print(f"⏰ Timestamp: {datetime.now().isoformat()}")
        
        # Connect to database
        conn = sqlite3.connect(str(DB_PATH))
        cursor = conn.cursor()
        
        # Delete all user data
        tables = ['conversations', 'memories', 'uploads', 'settings']
        
        for table in tables:
            cursor.execute(f"DELETE FROM {table} WHERE user_id = ?", (user_id,))
            deleted = cursor.rowcount
            print(f"  ✅ Deleted {deleted} rows from {table}")
        
        # Delete user account
        cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        print(f"  ✅ Deleted user account")
        
        conn.commit()
        conn.close()
        
        # Delete uploaded files
        if UPLOADS_DIR.exists():
            for file_path in UPLOADS_DIR.glob(f"{user_id}_*"):
                try:
                    file_path.unlink()
                    print(f"  ✅ Deleted file: {file_path.name}")
                except Exception as e:
                    print(f"  ⚠️ Failed to delete {file_path.name}: {e}")
        
        # Delete backups
        if BACKUP_DIR.exists():
            for backup_path in BACKUP_DIR.glob(f"user_{user_id}_*"):
                try:
                    backup_path.unlink()
                    print(f"  ✅ Deleted backup: {backup_path.name}")
                except Exception as e:
                    print(f"  ⚠️ Failed to delete {backup_path.name}: {e}")
        
        # Overwrite data (secure deletion)
        # In production, use secure deletion tools
        
        print(f"✅ EMERGENCY WIPE COMPLETE - User ID: {user_id}")
        
        return {
            "success": True,
            "message": "All data permanently deleted",
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        print(f"❌ EMERGENCY WIPE FAILED: {e}")
        raise HTTPException(status_code=500, detail=f"Wipe failed: {str(e)}")

@router.post("/emergency/wipe-all")
async def emergency_wipe_all(secret_code: str):
    """
    Nuclear option: Wipe ALL data for ALL users
    Requires secret code: "SATHI_NUCLEAR_WIPE_2026"
    USE WITH EXTREME CAUTION!
    """
    
    NUCLEAR_CODE = "SATHI_NUCLEAR_WIPE_2026"
    
    if secret_code != NUCLEAR_CODE:
        raise HTTPException(status_code=403, detail="Invalid secret code")
    
    print("☢️ NUCLEAR WIPE INITIATED - ALL DATA WILL BE DELETED")
    print(f"⏰ Timestamp: {datetime.now().isoformat()}")
    
    try:
        # Delete database
        if DB_PATH.exists():
            DB_PATH.unlink()
            print("  ✅ Deleted database")
        
        # Delete all uploads
        if UPLOADS_DIR.exists():
            shutil.rmtree(UPLOADS_DIR)
            UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
            print("  ✅ Deleted all uploads")
        
        # Delete all backups
        if BACKUP_DIR.exists():
            shutil.rmtree(BACKUP_DIR)
            BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            print("  ✅ Deleted all backups")
        
        print("✅ NUCLEAR WIPE COMPLETE")
        
        return {
            "success": True,
            "message": "ALL DATA PERMANENTLY DELETED",
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        print(f"❌ NUCLEAR WIPE FAILED: {e}")
        raise HTTPException(status_code=500, detail=f"Nuclear wipe failed: {str(e)}")
