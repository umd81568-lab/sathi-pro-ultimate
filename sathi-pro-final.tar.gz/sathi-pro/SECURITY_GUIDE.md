# 🔐 সাথী Pro - সম্পূর্ণ সুরক্ষা গাইড

## 🎯 সুরক্ষা স্তর

### স্তর ১: Admin Panel 🔑
- **Password:** `admin123`
- **অ্যাক্সেস:** সাধারণ সেটিংস
- **প্রয়োজন:** সাধারণ কনফিগারেশনের জন্য

### স্তর ২: Master Key 🗝️
- **আপনার তৈরি:** প্রথম setup এ
- **অ্যাক্সেস:** সাথী + সব কন্ট্রোল
- **প্রয়োজন:** সাথীর সাথে কথা বলতে

### স্তর ৩: Recovery Key 🔓
- **ডিফল্ট:** `SATHI_RECOVERY_2026`
- **ব্যবহার:** Master Key ভুলে গেলে
- **নিরাপত্তা:** গোপন রাখুন

### স্তর ৪: Emergency Wipe 💣
- **কোড:** `54321`
- **ফলাফল:** সব মুছে যাবে (5 সেকেন্ডে)
- **ব্যবহার:** জরুরি পরিস্থিতিতে

---

## 🚀 প্রথম ব্যবহার

### ১. Admin Login:
```
Settings → Admin Panel
Password: admin123
```

### ২. Master Key Setup:
```
প্রথমবার খোলার সময়:
1. আপনার পছন্দের Master Key তৈরি করুন
2. নিশ্চিত করুন
3. Recovery Key কপি করুন (গোপনে রাখুন)
```

### ৩. সাথী Access:
```
সাথী খুলতে:
1. Master Key দিন
2. অথবা Recovery Key ব্যবহার করুন
```

---

## 🔒 সুরক্ষা বৈশিষ্ট্য

### ✅ Multi-layer Protection:
- Admin password
- Master key encryption
- Recovery key backup
- Emergency wipe

### ✅ Failed Attempt Protection:
- 5 ভুল প্রচেষ্টা = 30 মিনিট lock
- লগ রাখে সব প্রচেষ্টা
- স্বয়ংক্রিয় unlock 30 মিনিট পরে

### ✅ Emergency Wipe Features:
- **কীবোর্ড শর্টকাট:** `Ctrl + Shift + Esc`
- **কোড:** `54321`
- **সময়:** 5 সেকেন্ড countdown
- **মুছে ফেলবে:**
  - সব চ্যাট
  - সব মেমোরি
  - সব ছবি
  - সব সেটিংস
  - ক্লাউড ডেটা
  - ব্রাউজার ক্যাশ
  - সব কুকি

---

## 🎮 ব্যবহার সিনারিও

### দৃশ্য ১: স্বাভাবিক ব্যবহার
```
1. Admin Panel খুলুন (admin123)
2. Master Key দিন (আপনার key)
3. সাথীর সাথে কথা বলুন
```

### দৃশ্য ২: Master Key ভুলে গেছেন
```
1. Recovery Key ব্যবহার করুন
   (SATHI_RECOVERY_2026)
2. নতুন Master Key সেট করুন
```

### দৃশ্য ৩: জরুরি পরিস্থিতি
```
1. Ctrl+Shift+Esc চাপুন
   অথবা
2. Master Key জায়গায় "54321" লিখুন
3. 5 সেকেন্ডে সব মুছে যাবে
```

---

## ⚠️ গুরুত্বপূর্ণ সতর্কতা

### 🔴 Emergency Wipe:
```
⚠️ এটি PERMANENT!
- কোনো undo নেই
- কোনো recovery নেই
- সব চিরতরে হারিয়ে যাবে
```

### 🟡 Recovery Key:
```
⚠️ গোপন রাখুন!
- কেউ পেলে সাথী access করতে পারবে
- নিরাপদ জায়গায় রাখুন
- শেয়ার করবেন না
```

### 🟢 Master Key:
```
✅ ভালো Master Key:
- কমপক্ষে 8 অক্ষর
- নাম্বার + অক্ষর মিশ্রিত
- মনে রাখা সহজ, অনুমান করা কঠিন
```

---

## 🛡️ সুরক্ষা চেকলিস্ট

প্রথম setup:
- [ ] Admin Panel test করুন
- [ ] Strong Master Key তৈরি করুন
- [ ] Recovery Key কপি করে নিরাপদ রাখুন
- [ ] Emergency Wipe test করুন (সতর্ক!)

নিয়মিত:
- [ ] Master Key মনে আছে?
- [ ] Recovery Key নিরাপদ?
- [ ] কেউ access করতে পারছে না?

---

## 🔑 পাসওয়ার্ড তালিকা

### স্তর ১ - Admin Panel:
```
Password: admin123
Change করতে: backend/app.py → Line 120
```

### স্তর ২ - Master Key:
```
আপনার তৈরি করা
ভুলে গেলে: Recovery Key ব্যবহার করুন
```

### স্তর ৩ - Recovery Key:
```
Default: SATHI_RECOVERY_2026
Change করতে: frontend/app/js/security.js → Line 15
```

### স্তর ৪ - Emergency Wipe:
```
Code: 54321
Change করতে: frontend/app/js/security.js → Line 16
```

---

## 🆘 সমস্যা সমাধান

### "লক হয়ে গেছে!":
```
অপেক্ষা করুন: 30 মিনিট
অথবা
Backend reset: rm backend/data/sathi.db
```

### "Master Key কাজ করছে না!":
```
1. Recovery Key ব্যবহার করুন
2. নতুন Master Key সেট করুন
```

### "Emergency Wipe কাজ করছে না!":
```
1. Ctrl+Shift+Esc চাপুন
2. "54321" কোড দিন
3. 5 সেকেন্ড অপেক্ষা করুন
```

---

## 💡 Advanced টিপস

### কাস্টম Admin Password:
```python
# backend/app.py (Line ~120)
self.ADMIN_PASSWORD = self.hash('YOUR_PASSWORD')
```

### কাস্টম Recovery Key:
```javascript
// frontend/app/js/security.js (Line ~15)
this.DEFAULT_MASTER_KEY = this.hash('YOUR_SECRET_KEY');
```

### কাস্টম Emergency Code:
```javascript
// frontend/app/js/security.js (Line ~16)
this.EMERGENCY_WIPE_CODE = this.hash('YOUR_CODE');
```

### Lockout সময় পরিবর্তন:
```javascript
// frontend/app/js/security.js (Line ~22)
this.lockoutTime = 30 * 60 * 1000; // milliseconds
```

---

## 🎯 সুরক্ষা লেভেল

### 🟢 Low Security (Default):
- Admin: admin123
- Master Key: সাধারণ
- Recovery: ডিফল্ট

### 🟡 Medium Security (প্রস্তাবিত):
- Admin: নিজের পাসওয়ার্ড
- Master Key: শক্তিশালী
- Recovery: পরিবর্তিত

### 🔴 High Security (সর্বোচ্চ):
- সব পাসওয়ার্ড পরিবর্তিত
- 2FA enabled (custom)
- Biometric (custom)
- Hardware key (custom)

---

## 📞 জরুরি যোগাযোগ

সমস্যা হলে:
1. SECURITY_GUIDE.md পড়ুন
2. Backend logs দেখুন
3. সাহায্য চান

**মনে রাখবেন:**
- Recovery Key নিরাপদ রাখুন
- Emergency Wipe সাবধানে ব্যবহার করুন
- নিয়মিত backup করুন

---

**সাথী সুরক্ষিত!** 🔐
