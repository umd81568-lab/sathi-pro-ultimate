#!/bin/bash

# সাথী Pro - সম্পূর্ণ সিস্টেম চেক ও Deploy
# Full security audit + deployment

set -e

echo "🔍 সাথী Pro - সম্পূর্ণ সিস্টেম চেক শুরু..."
echo "=================================================="

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

ERRORS=0
WARNINGS=0

# =====================================================
# 1. File Structure Check
# =====================================================

echo -e "\n${BLUE}[1/10] File Structure Check...${NC}"

required_files=(
    "backend/app.py"
    "backend/security_middleware.py"
    "backend/emergency_wipe.py"
    "backend/requirements.txt"
    "frontend/app/index.html"
    "frontend/app/js/app.js"
    "frontend/app/js/security.js"
    "frontend/sathi-cloud.js"
    "INSTALL.md"
    "SECURITY_GUIDE.md"
)

for file in "${required_files[@]}"; do
    if [ -f "$file" ]; then
        echo -e "  ${GREEN}✓${NC} $file"
    else
        echo -e "  ${RED}✗${NC} $file - MISSING!"
        ((ERRORS++))
    fi
done

# =====================================================
# 2. Python Dependencies Check
# =====================================================

echo -e "\n${BLUE}[2/10] Python Dependencies Check...${NC}"

cd backend

if python3 -c "import fastapi, uvicorn, cryptography, requests" 2>/dev/null; then
    echo -e "  ${GREEN}✓${NC} All Python packages available"
else
    echo -e "  ${YELLOW}⚠${NC} Installing Python packages..."
    pip3 install -q -r requirements.txt
    if [ $? -eq 0 ]; then
        echo -e "  ${GREEN}✓${NC} Packages installed successfully"
    else
        echo -e "  ${RED}✗${NC} Failed to install packages"
        ((ERRORS++))
    fi
fi

cd ..

# =====================================================
# 3. Security Configuration Check
# =====================================================

echo -e "\n${BLUE}[3/10] Security Configuration Check...${NC}"

# Check admin password
if grep -q "admin123" backend/app.py; then
    echo -e "  ${YELLOW}⚠${NC} Default admin password detected"
    echo -e "    Recommendation: Change in production"
    ((WARNINGS++))
fi

# Check master key
if grep -q "SATHI_RECOVERY_2026" frontend/app/js/security.js; then
    echo -e "  ${GREEN}✓${NC} Recovery key configured"
else
    echo -e "  ${RED}✗${NC} Recovery key not found"
    ((ERRORS++))
fi

# Check emergency wipe
if grep -q "54321" frontend/app/js/security.js; then
    echo -e "  ${GREEN}✓${NC} Emergency wipe configured"
else
    echo -e "  ${RED}✗${NC} Emergency wipe not configured"
    ((ERRORS++))
fi

# =====================================================
# 4. Database Setup Check
# =====================================================

echo -e "\n${BLUE}[4/10] Database Setup Check...${NC}"

if [ -f "backend/data/sathi.db" ]; then
    echo -e "  ${YELLOW}⚠${NC} Existing database found"
    echo -e "    Will be used (no reset)"
else
    echo -e "  ${GREEN}✓${NC} New database will be created"
fi

# =====================================================
# 5. Port Availability Check
# =====================================================

echo -e "\n${BLUE}[5/10] Port Availability Check...${NC}"

if lsof -Pi :8000 -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo -e "  ${YELLOW}⚠${NC} Port 8000 already in use"
    echo -e "    Will kill existing process"
    pkill -f "python3 app.py" || true
    sleep 2
    if lsof -Pi :8000 -sTCP:LISTEN -t >/dev/null 2>&1; then
        echo -e "  ${RED}✗${NC} Failed to free port 8000"
        ((ERRORS++))
    else
        echo -e "  ${GREEN}✓${NC} Port 8000 now available"
    fi
else
    echo -e "  ${GREEN}✓${NC} Port 8000 available"
fi

# =====================================================
# 6. Firewall Check
# =====================================================

echo -e "\n${BLUE}[6/10] Firewall Configuration Check...${NC}"

if command -v ufw >/dev/null 2>&1; then
    if ufw status | grep -q "Status: active"; then
        echo -e "  ${GREEN}✓${NC} UFW firewall active"
        
        # Check rules
        if ufw status | grep -q "8000"; then
            echo -e "  ${GREEN}✓${NC} Port 8000 allowed"
        else
            echo -e "  ${YELLOW}⚠${NC} Port 8000 not in firewall rules"
            echo -e "    Add with: ufw allow 8000"
            ((WARNINGS++))
        fi
    else
        echo -e "  ${YELLOW}⚠${NC} UFW firewall not active"
        echo -e "    Enable with: ufw enable"
        ((WARNINGS++))
    fi
else
    echo -e "  ${YELLOW}⚠${NC} UFW not installed"
    echo -e "    Install with: apt install ufw"
    ((WARNINGS++))
fi

# =====================================================
# 7. Nginx Check
# =====================================================

echo -e "\n${BLUE}[7/10] Nginx Configuration Check...${NC}"

if command -v nginx >/dev/null 2>&1; then
    echo -e "  ${GREEN}✓${NC} Nginx installed"
    
    if systemctl is-active --quiet nginx; then
        echo -e "  ${GREEN}✓${NC} Nginx running"
    else
        echo -e "  ${YELLOW}⚠${NC} Nginx not running"
        echo -e "    Start with: systemctl start nginx"
        ((WARNINGS++))
    fi
    
    # Check config
    if [ -f "/etc/nginx/sites-available/sathi" ]; then
        echo -e "  ${GREEN}✓${NC} Sathi nginx config exists"
    else
        echo -e "  ${YELLOW}⚠${NC} Sathi nginx config not found"
        echo -e "    Will be created during deployment"
    fi
else
    echo -e "  ${YELLOW}⚠${NC} Nginx not installed"
    echo -e "    Install with: apt install nginx"
    ((WARNINGS++))
fi

# =====================================================
# 8. SSL Certificate Check
# =====================================================

echo -e "\n${BLUE}[8/10] SSL Certificate Check...${NC}"

if command -v certbot >/dev/null 2>&1; then
    echo -e "  ${GREEN}✓${NC} Certbot installed"
    
    # Check certificates
    if certbot certificates 2>/dev/null | grep -q "Certificate Name"; then
        echo -e "  ${GREEN}✓${NC} SSL certificates found"
    else
        echo -e "  ${YELLOW}⚠${NC} No SSL certificates"
        echo -e "    Recommendation: Setup HTTPS for production"
        ((WARNINGS++))
    fi
else
    echo -e "  ${YELLOW}⚠${NC} Certbot not installed"
    echo -e "    Install with: apt install certbot python3-certbot-nginx"
    ((WARNINGS++))
fi

# =====================================================
# 9. Security Headers Test
# =====================================================

echo -e "\n${BLUE}[9/10] Security Features Check...${NC}"

# Check rate limiting
if grep -q "max_requests_per_minute" backend/security_middleware.py; then
    echo -e "  ${GREEN}✓${NC} Rate limiting configured"
else
    echo -e "  ${RED}✗${NC} Rate limiting not found"
    ((ERRORS++))
fi

# Check IP blocking
if grep -q "blacklist" backend/security_middleware.py; then
    echo -e "  ${GREEN}✓${NC} IP blocking configured"
else
    echo -e "  ${RED}✗${NC} IP blocking not found"
    ((ERRORS++))
fi

# Check SQL injection protection
if grep -q "suspicious_patterns" backend/security_middleware.py; then
    echo -e "  ${GREEN}✓${NC} Attack pattern detection configured"
else
    echo -e "  ${RED}✗${NC} Attack detection not found"
    ((ERRORS++))
fi

# =====================================================
# 10. Final System Check
# =====================================================

echo -e "\n${BLUE}[10/10] Final System Check...${NC}"

# Check disk space
available_space=$(df -BG / | tail -1 | awk '{print $4}' | sed 's/G//')
if [ "$available_space" -gt 1 ]; then
    echo -e "  ${GREEN}✓${NC} Sufficient disk space: ${available_space}GB"
else
    echo -e "  ${YELLOW}⚠${NC} Low disk space: ${available_space}GB"
    ((WARNINGS++))
fi

# Check memory
available_mem=$(free -m | awk 'NR==2{print $7}')
if [ "$available_mem" -gt 500 ]; then
    echo -e "  ${GREEN}✓${NC} Sufficient memory: ${available_mem}MB"
else
    echo -e "  ${YELLOW}⚠${NC} Low memory: ${available_mem}MB"
    ((WARNINGS++))
fi

# Check Python version
python_version=$(python3 --version 2>&1 | awk '{print $2}' | cut -d. -f1,2)
if (( $(echo "$python_version >= 3.8" | bc -l) )); then
    echo -e "  ${GREEN}✓${NC} Python version: $python_version"
else
    echo -e "  ${RED}✗${NC} Python version too old: $python_version (need 3.8+)"
    ((ERRORS++))
fi

# =====================================================
# Summary
# =====================================================

echo ""
echo "=================================================="
echo -e "${BLUE}System Check Summary:${NC}"
echo "=================================================="

if [ $ERRORS -eq 0 ]; then
    echo -e "${GREEN}✓ No critical errors found${NC}"
else
    echo -e "${RED}✗ Found $ERRORS critical error(s)${NC}"
fi

if [ $WARNINGS -eq 0 ]; then
    echo -e "${GREEN}✓ No warnings${NC}"
else
    echo -e "${YELLOW}⚠ Found $WARNINGS warning(s)${NC}"
fi

echo ""

# =====================================================
# Deployment Decision
# =====================================================

if [ $ERRORS -gt 0 ]; then
    echo -e "${RED}❌ DEPLOYMENT BLOCKED${NC}"
    echo "Critical errors must be fixed before deployment."
    echo "Please review the errors above and try again."
    exit 1
fi

if [ $WARNINGS -gt 0 ]; then
    echo -e "${YELLOW}⚠️  WARNINGS DETECTED${NC}"
    echo "System can be deployed but some optimizations are recommended."
    echo ""
    read -p "Continue with deployment? (y/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Deployment cancelled."
        exit 0
    fi
fi

# =====================================================
# Deployment
# =====================================================

echo ""
echo "=================================================="
echo -e "${GREEN}🚀 Starting Deployment...${NC}"
echo "=================================================="

# Install system dependencies
echo -e "\n${BLUE}Installing system dependencies...${NC}"
apt-get update -qq
apt-get install -y python3-pip nginx ufw fail2ban >/dev/null 2>&1

# Install Python packages
echo -e "${BLUE}Installing Python packages...${NC}"
cd backend
pip3 install -q -r requirements.txt

# Configure firewall
echo -e "${BLUE}Configuring firewall...${NC}"
ufw --force enable
ufw allow 22    # SSH
ufw allow 80    # HTTP
ufw allow 443   # HTTPS
ufw allow 8000  # Backend API

# Stop existing backend
echo -e "${BLUE}Stopping existing backend...${NC}"
pkill -f "python3 app.py" || true
sleep 2

# Start backend
echo -e "${BLUE}Starting backend...${NC}"
nohup python3 app.py > /var/log/sathi-backend.log 2>&1 &
sleep 3

# Check if backend started
if pgrep -f "python3 app.py" > /dev/null; then
    echo -e "  ${GREEN}✓${NC} Backend started successfully"
else
    echo -e "  ${RED}✗${NC} Backend failed to start"
    echo "Check logs: tail -f /var/log/sathi-backend.log"
    exit 1
fi

cd ..

# Configure Nginx
echo -e "${BLUE}Configuring Nginx...${NC}"

cat > /etc/nginx/sites-available/sathi << 'EOF'
# Security headers
add_header X-Frame-Options "DENY" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;

# Rate limiting
limit_req_zone $binary_remote_addr zone=api_limit:10m rate=10r/s;
limit_req_zone $binary_remote_addr zone=login_limit:10m rate=5r/m;

server {
    listen 80;
    server_name 207.180.249.220;

    # API endpoints with rate limiting
    location /api/ {
        limit_req zone=api_limit burst=20 nodelay;
        
        proxy_pass http://localhost:8000/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
        
        # Timeout settings
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }

    # Login endpoint with strict rate limiting
    location /api/auth/ {
        limit_req zone=login_limit burst=3 nodelay;
        
        proxy_pass http://localhost:8000/auth/;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    # Frontend
    location / {
        root /root/sathi-pro/frontend/app;
        index index.html;
        try_files $uri $uri/ /index.html;
        
        # Cache static files
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }

    # Block common attack paths
    location ~ /\. {
        deny all;
        return 404;
    }

    location ~ /\.git {
        deny all;
        return 404;
    }
}
EOF

ln -sf /etc/nginx/sites-available/sathi /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx

echo -e "  ${GREEN}✓${NC} Nginx configured"

# Configure Fail2Ban (intrusion prevention)
echo -e "${BLUE}Configuring Fail2Ban...${NC}"

cat > /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[sshd]
enabled = true
port = 22
filter = sshd
logpath = /var/log/auth.log

[nginx-limit-req]
enabled = true
port = http,https
filter = nginx-limit-req
logpath = /var/log/nginx/error.log

[sathi-backend]
enabled = true
port = 8000
filter = sathi-backend
logpath = /var/log/sathi-backend.log
maxretry = 3
EOF

systemctl enable fail2ban
systemctl restart fail2ban

echo -e "  ${GREEN}✓${NC} Fail2Ban configured"

# =====================================================
# Final Tests
# =====================================================

echo ""
echo "=================================================="
echo -e "${BLUE}Running Final Tests...${NC}"
echo "=================================================="

# Test backend API
echo -e "\n${BLUE}Testing backend API...${NC}"
sleep 2
if curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/ | grep -q "200"; then
    echo -e "  ${GREEN}✓${NC} Backend API responding"
else
    echo -e "  ${RED}✗${NC} Backend API not responding"
fi

# Test frontend
echo -e "\n${BLUE}Testing frontend...${NC}"
if curl -s -o /dev/null -w "%{http_code}" http://localhost/ | grep -q "200"; then
    echo -e "  ${GREEN}✓${NC} Frontend accessible"
else
    echo -e "  ${YELLOW}⚠${NC} Frontend not accessible (check Nginx)"
fi

# =====================================================
# Success!
# =====================================================

echo ""
echo "=================================================="
echo -e "${GREEN}✅ DEPLOYMENT SUCCESSFUL!${NC}"
echo "=================================================="
echo ""
echo "📍 Access URLs:"
echo "   Frontend: http://207.180.249.220"
echo "   Backend:  http://207.180.249.220:8000"
echo "   API Docs: http://207.180.249.220:8000/docs"
echo ""
echo "🔐 Security Features:"
echo "   ✓ IP Blocking & Whitelisting"
echo "   ✓ Rate Limiting (10 req/sec)"
echo "   ✓ Login Protection (5 attempts/min)"
echo "   ✓ DDoS Protection (Fail2Ban)"
echo "   ✓ SQL Injection Prevention"
echo "   ✓ XSS Protection"
echo "   ✓ CSRF Protection"
echo "   ✓ Emergency Wipe System"
echo ""
echo "📊 System Status:"
echo "   Backend: $(pgrep -f 'python3 app.py' > /dev/null && echo 'Running ✓' || echo 'Stopped ✗')"
echo "   Nginx: $(systemctl is-active --quiet nginx && echo 'Running ✓' || echo 'Stopped ✗')"
echo "   Firewall: $(ufw status | grep -q 'Status: active' && echo 'Active ✓' || echo 'Inactive ✗')"
echo "   Fail2Ban: $(systemctl is-active --quiet fail2ban && echo 'Active ✓' || echo 'Inactive ✗')"
echo ""
echo "📝 Logs:"
echo "   Backend: tail -f /var/log/sathi-backend.log"
echo "   Nginx: tail -f /var/log/nginx/error.log"
echo "   Fail2Ban: tail -f /var/log/fail2ban.log"
echo ""
echo "🎯 Next Steps:"
echo "   1. Test: Open http://207.180.249.220"
echo "   2. Register: Create your account"
echo "   3. Setup: Configure Master Key"
echo "   4. Enjoy: Start chatting with সাথী!"
echo ""
echo "=================================================="
echo -e "${GREEN}সাথী Pro সম্পূর্ণ প্রস্তুত!${NC} 💕"
echo "=================================================="
